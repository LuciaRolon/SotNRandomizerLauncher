-- Castlevania SotN Saturn - Randomizer Item Tracker
-- By MottZilla
-- December 12th 2023
-- Some Images taken from https://github.com/TalicZealot/SotN-Relic-Tracker

EndScript = false


function closewindow()
	forms.destroyall()
	console.log("Window Closed!")
	EndScript = true
end


-- was +370 and 440
myForm = forms.newform(1060,550,"SotN Saturn Tracker",closewindow)
myPB = forms.pictureBox(myForm,0,0,372 + 740,880)
forms.drawBox(myPB,0,0,372+742,880, 0xFF000000, 0xFF000000)

forms.drawBox(myPB,0,0,372,290+120,0xFF110011, 0xFF110011)	-- Draw Item Box BG

SeedName = ""
SeedTime = ""
inp_dis = 0
updatefc = 0
updatemap = 0
curX = 0
curY = 0
perRow = 6
curHour = 0
curMin = 0
curSecs = 0
curFrames = 0
timestr = "Time - 00:00"
RunStartFrame = 0
RunEndFrame = 0
NoHearts = 0
curCharacter = 2
mapsize = 2
curCastle = 0
lastCastleRedraw = 0
zone = 0
dracula_spawned = 0
checkset = 3

ShowMapPos = 1
PreviousX = -10	-- For Live Position trail
PreviousY = -10
PreviousCastleX = -1
PreviousCastleY = -1

-- Relic Status
RelicArray = {}
RelicArrayOld = {}

for i=0, 0x20 do
	RelicArray[i] = 7
	RelicArrayOld[i] = 1
end

ki_GoldRing = 0
ki_SilverRing = 0
ki_HolyGlasses = 0
ki_SpikeBreaker = 0
ki_LibraryCard = 0

kiu_GoldRing = 1
kiu_SilverRing = 1
kiu_HolyGlasses = 1
kiu_SpikeBreaker = 1
kiu_LibraryCard = 1

-- Relic Timers
rt_SoulOfBat = 0
rt_FireOfBat = 0
rt_EchoOfBat = 0
rt_ForceOfEcho = 0
rt_SoulOfWolf = 0
rt_PowerOfWolf = 0
rt_SkillOfWolf = 0
rt_FormOfMist = 0
rt_PowerOfMist = 0
rt_GasCloud = 0
rt_CubeOfZoe = 0
rt_SpiritOrb = 0
rt_GravityBoots = 0
rt_LeapStone = 0
rt_HolySymbol = 0
rt_FaerieScroll = 0
rt_JewelOfOpen = 0
rt_MermanStatue = 0
rt_BatCard = 0
rt_GhostCard = 0
rt_FaerieCard = 0
rt_DemonCard = 0
rt_SwordCard = 0
rt_SpriteCard = 0
rt_NoseDevilCard = 0
rt_HeartOfVlad = 0
rt_ToothOfVlad = 0
rt_RibOfVlad = 0
rt_RingOfVlad = 0
rt_EyeOfVlad = 0
rt_GodSpeedShoes = 0


-- Create Map Array
rec_map1 = {}
for i=0, 4096 do
	rec_map1[i] = 0
end


-- Create Map Array
rec_map2 = {}
for i=0, 4096 do
	rec_map1[i] = 0
end

function round(number)
  return number - (number % 1)
end


function autotimer()
	-- Global Variable, used elsewhere.
	zone = memory.read_u8(0x5D750,"Work Ram High")

		curHour = memory.read_u8(0x5C9D6,"Work Ram High")
		curMin = memory.read_u8(0x5C9DA,"Work Ram High")
		curSecs = memory.read_u8(0x5C9DE,"Work Ram High")
		curFrames = memory.read_u8(0x5C9E2,"Work Ram High")

	-- Maria/Richter
	if(RunStartFrame == 0 and zone == 0x41 and curHour == 0 and curMin == 0 and curSecs == 0xF and curFrames == 3) then
		console.log("Run Started!")
		RunStartFrame = emu.framecount()
		console.log("Frame:" .. RunStartFrame)
		dracula_spawned = 0
	end
	-- Alucard
	if(RunStartFrame == 0 and zone == 0x1F and curHour == 0 and curMin == 0 and curSecs == 4 and curFrames >= 0x19) then
		console.log("Run Started!")
		RunStartFrame = emu.framecount()
		console.log("Frame:" .. RunStartFrame)
		dracula_spawned = 0
	end

	if(zone == 0x38 and RunEndFrame == 0) then
		if(memory.read_u8(0x9D1B5) == 0x27) then dracula_spawned = 1 end
		if(dracula_spawned == 1 and memory.read_u8(0x9D1B5,"Work Ram High") > 0x7F) then
			console.log("Run Ended! " .. "Frame:" .. emu.framecount())
			RunEndFrame = emu.framecount()
		end
	end

end

-- For Emu Frame Count Timer from Run Start
function buildautotimestr()
	if(RunStartFrame == 0) then
		timestr = "Run Timer - ??:??:??"
		return
	end
	
	if(RunEndFrame > 0) then
		curHour = (RunEndFrame - RunStartFrame) / 216000 % 99
		curMin = ((RunEndFrame - RunStartFrame) / 3600) % 60
		curSecs = ((RunEndFrame - RunStartFrame) / 60) % 60
	end

	if(RunEndFrame == 0) then
		curHour = (emu.framecount() - RunStartFrame) / 216000 % 99
		curMin = ((emu.framecount() - RunStartFrame) / 3600) % 60
		curSecs = ((emu.framecount() - RunStartFrame) / 60) % 60
	end

	curHour = math.floor(curHour)
	curMin = math.floor(curMin)
	curSecs = math.floor(curSecs)
	timestr = "Run Timer - "	-- Run Timer
	if curHour < 10 then
		timestr = timestr .. "0"
	end
	timestr = timestr .. curHour .. ":"
	if curMin < 10 then
		timestr = timestr .. "0"
	end
	timestr = timestr .. curMin .. ":"
	if curSecs < 10 then
		timestr = timestr .. "0"
	end
	timestr = timestr .. curSecs
end


-- For In Game Timer
function buildtimestr()
	--if memory.read_u8(0x3C9A0,"MainRAM") > -1 then
		curHour = memory.read_u8(0x5C9D6,"Work Ram High")
		curMin = memory.read_u8(0x5C9DA,"Work Ram High")
		curSecs = memory.read_u8(0x5C9DE,"Work Ram High")
	--end
	timestr = "Game Time - "
	if curHour < 10 then
		timestr = timestr .. "0"
	end
	timestr = timestr .. curHour .. ":"
	if curMin < 10 then
		timestr = timestr .. "0"
	end
	timestr = timestr .. curMin .. ":"
	if curSecs < 10 then
		timestr = timestr .. "0"
	end
	timestr = timestr .. curSecs
end

function movecursor()
	curX = curX + 60
	if curX >= (perRow * 60) then
		curX = 0
		curY = curY + 60
	end
end

function UpdateRecentRelics()
	local KeyItemCount

	-- Save Old Relic Status
	for i=0, 0x20 do
		RelicArrayOld[i] = RelicArray[i]
	end

	-- Update Relic Status
	RelicArray = memory.read_bytes_as_array(0x5C6F0,0x20)

	-- Update Key Items
	KeyItemCount = memory.read_u8(0x5C812,"Work Ram High")
	if KeyItemCount ~= ki_GoldRing then
		ki_GoldRing = KeyItemCount
		kiu_GoldRing = 1
	end
	KeyItemCount = memory.read_u8(0x5C815,"Work Ram High")
	if KeyItemCount ~= ki_SilverRing then
		ki_SilverRing = KeyItemCount
		kiu_SilverRing = 1
	end
	KeyItemCount = memory.read_u8(0x5C7ED,"Work Ram High")
	if KeyItemCount ~= ki_HolyGlasses then
		ki_HolyGlasses = KeyItemCount
		kiu_HolyGlasses = 1
	end
	KeyItemCount = memory.read_u8(0x5C7D9,"Work Ram High")
	if KeyItemCount ~= ki_SpikeBreaker then
		ki_SpikeBreaker = KeyItemCount
		kiu_SpikeBreaker = 1
	end
	KeyItemCount = memory.read_u8(0x5C7C3,"Work Ram High")
	if KeyItemCount ~= ki_LibraryCard then
		ki_LibraryCard = KeyItemCount
		kiu_LibraryCard = 1
	end


	if RelicArray[2] > 0 then
		if rt_SoulOfBat < 600 then rt_SoulOfBat = rt_SoulOfBat + 1 end
	else
		rt_SoulOfBat = 0
	end

	if RelicArray[1] > 0 then
		if rt_FireOfBat < 600 then rt_FireOfBat = rt_FireOfBat + 1 end
	else
		rt_FireOfBat = 0
	end

	if RelicArray[4] > 0 then
		if rt_EchoOfBat < 600 then rt_EchoOfBat = rt_EchoOfBat + 1 end
	else
		rt_EchoOfBat = 0
	end

	if RelicArray[3] > 0 then
		if rt_ForceOfEcho < 600 then rt_ForceOfEcho = rt_ForceOfEcho + 1 end
	else
		rt_ForceOfEcho = 0
	end

	if RelicArray[6] > 0 then
		if rt_SoulOfWolf < 600 then rt_SoulOfWolf = rt_SoulOfWolf + 1 end
	else
		rt_SoulOfWolf = 0
	end

	if RelicArray[5] > 0 then
		if rt_PowerOfWolf < 600 then rt_PowerOfWolf = rt_PowerOfWolf + 1 end
	else
		rt_PowerOfWolf = 0
	end

	if RelicArray[8] > 0 then
		if rt_SkillOfWolf < 600 then rt_SkillOfWolf = rt_SkillOfWolf + 1 end
	else
		rt_SkillOfWolf = 0
	end

	if RelicArray[7] > 0 then
		if rt_FormOfMist < 600 then rt_FormOfMist = rt_FormOfMist + 1 end
	else
		rt_FormOfMist = 0
	end

	if RelicArray[10] > 0 then
		if rt_PowerOfMist < 600 then rt_PowerOfMist = rt_PowerOfMist + 1 end
	else
		rt_PowerOfMist = 0
	end

	if RelicArray[9] > 0 then
		if rt_GasCloud < 600 then rt_GasCloud = rt_GasCloud + 1 end
	else
		rt_GasCloud = 0
	end

	if RelicArray[12] > 0 then
		if rt_CubeOfZoe < 600 then rt_CubeOfZoe = rt_CubeOfZoe + 1 end
	else
		rt_CubeOfZoe = 0
	end

	if RelicArray[11] > 0 then
		if rt_SpiritOrb < 600 then rt_SpiritOrb = rt_SpiritOrb + 1 end
	else
		rt_SpiritOrb = 0
	end

	if RelicArray[14] > 0 then
		if rt_GravityBoots < 600 then rt_GravityBoots = rt_GravityBoots + 1 end
	else
		rt_GravityBoots = 0
	end

	if RelicArray[13] > 0 then
		if rt_LeapStone < 600 then rt_LeapStone = rt_LeapStone + 1 end
	else
		rt_LeapStone = 0
	end

	if RelicArray[16] > 0 then
		if rt_HolySymbol < 600 then rt_HolySymbol = rt_HolySymbol + 1 end
	else
		rt_HolySymbol = 0
	end

	if RelicArray[15] > 2 then
		if rt_FaerieScroll < 600 then rt_FaerieScroll = rt_FaerieScroll + 1 end
	else
		rt_FaerieScroll = 0
	end

	if RelicArray[18] > 0 then
		if rt_JewelOfOpen < 600 then rt_JewelOfOpen = rt_JewelOfOpen + 1 end
	else
		rt_JewelOfOpen = 0
	end

	if RelicArray[17] > 0 then
		if rt_MermanStatue < 600 then rt_MermanStatue = rt_MermanStatue + 1 end
	else
		rt_MermanStatue = 0
	end

	if RelicArray[20] > 0 then
		if rt_BatCard < 600 then rt_BatCard = rt_BatCard + 1 end
	else
		rt_BatCard = 0
	end

	if RelicArray[19] > 0 then
		if rt_GhostCard < 600 then rt_GhostCard = rt_GhostCard + 1 end
	else
		rt_GhostCard = 0
	end

	if RelicArray[22] > 0 then
		if rt_FaerieCard < 600 then rt_FaerieCard = rt_FaerieCard + 1 end
	else
		rt_FaerieCard = 0
	end

	if RelicArray[21] > 0 then
		if rt_DemonCard < 600 then rt_DemonCard = rt_DemonCard + 1 end
	else
		rt_DemonCard = 0
	end

	if RelicArray[24] > 0 then
		if rt_SwordCard < 600 then rt_SwordCard = rt_SwordCard + 1 end
	else
		rt_SwordCard = 0
	end

	if RelicArray[23] > 0 then
		if rt_SpriteCard < 600 then rt_SpriteCard = rt_SpriteCard + 1 end
	else
		rt_SpriteCard = 0
	end

	if RelicArray[26] > 0 then
		if rt_NoseDevilCard < 600 then rt_NoseDevilCard = rt_NoseDevilCard + 1 end
	else
		rt_NoseDevilCard = 0
	end

	if RelicArray[25] > 0 then
		if rt_HeartOfVlad < 600 then rt_HeartOfVlad = rt_HeartOfVlad + 1 end
	else
		rt_HeartOfVlad = 0
	end

	if RelicArray[28] > 0 then
		if rt_ToothOfVlad < 600 then rt_ToothOfVlad = rt_ToothOfVlad + 1 end
	else
		rt_ToothOfVlad = 0
	end

	if RelicArray[27] > 0 then
		if rt_RibOfVlad < 600 then rt_RibOfVlad = rt_RibOfVlad + 1 end
	else
		rt_RibOfVlad = 0
	end

	if RelicArray[30] > 0 then
		if rt_RingOfVlad < 600 then rt_RingOfVlad = rt_RingOfVlad + 1 end
	else
		rt_RingOfVlad = 0
	end

	if RelicArray[29] > 0 then
		if rt_EyeOfVlad < 600 then rt_EyeOfVlad = rt_EyeOfVlad + 1 end
	else
		rt_EyeOfVlad = 0
	end

	if RelicArray[32] > 0 then
		if rt_GodSpeedShoes < 600 then rt_GodSpeedShoes = rt_GodSpeedShoes + 1 end
	else
		rt_GodSpeedShoes = 0
	end

end

-- Draws all relics and the Timer
function updatetracker()
	local fcards = 0
	curCharacter = memory.read_u8(0x5C6D2,"Work Ram High")

	UpdateRecentRelics()

	curX = 0
	curY = 0
	--forms.drawBox(myPB,0,0,372,290+120,0xFF110011, 0xFF110011)
	--forms.drawBox(myPB,372,0,742,290+120, 0xFF000000, 0xFF000000)

	-- Drawing of Relics Begins
	-- Draw only if Update is Needed

	-- Soul of Bat
	if RelicArray[2] ~= RelicArrayOld[2] then
		forms.drawBox(myPB,curX,curY,curX+59,curY+59,0xFF110011, 0xFF110011)	-- Clear to BG Color
		if RelicArray[2] > 0 then
			forms.drawImage(myPB,"Images/SoulOfBat.png",curX,curY,60,60,true)
		else
			forms.drawImage(myPB,"Images/Dark_SoulOfBat.png",curX,curY,60,60,true)
		end
	end
	if rt_SoulOfBat > 0 and rt_SoulOfBat < 600 then
		forms.drawBox(myPB,curX+1,curY+1,curX+59,curY+59,0xFFfce803, 0x00000000)
	end
	if rt_SoulOfBat > 0 and rt_SoulOfBat == 600 then
		forms.drawBox(myPB,curX+1,curY+1,curX+59,curY+59,0xFF110011, 0x00000000)
		rt_SoulOfBat = 601
	end
	movecursor()

	-- Fire of Bat
	if RelicArray[1] ~= RelicArrayOld[1] then
		forms.drawBox(myPB,curX,curY,curX+59,curY+59,0xFF110011, 0xFF110011)	-- Clear to BG Color
		if RelicArray[1] > 0 then
			forms.drawImage(myPB,"Images/FireOfBat.png",curX,curY,60,60,true)
		else
			forms.drawImage(myPB,"Images/Dark_FireOfBat.png",curX,curY,60,60,true)		
		end
	end
	if rt_FireOfBat > 0 and rt_FireOfBat < 600 then
		forms.drawBox(myPB,curX+1,curY+1,curX+59,curY+59,0xFFfce803, 0x00000000)
	end
	if rt_FireOfBat > 0 and rt_FireOfBat == 600 then
		forms.drawBox(myPB,curX+1,curY+1,curX+59,curY+59,0xFF110011, 0x00000000)
		rt_FireOfBat = 601
	end
	movecursor()

	-- Echo Of Bat
	if RelicArray[4] ~= RelicArrayOld[4] then
		forms.drawBox(myPB,curX,curY,curX+59,curY+59,0xFF110011, 0xFF110011)	-- Clear to BG Color
		if RelicArray[4] > 0 then
			forms.drawImage(myPB,"Images/EchoOfBat.png",curX,curY,60,60,true)
		else
			forms.drawImage(myPB,"Images/Dark_EchoOfBat.png",curX,curY,60,60,true)		
		end
	end
	if rt_EchoOfBat > 0 and rt_EchoOfBat < 600 then
		forms.drawBox(myPB,curX+1,curY+1,curX+59,curY+59,0xFFfce803, 0x00000000)
	end
	if rt_EchoOfBat > 0 and rt_EchoOfBat == 600 then
		forms.drawBox(myPB,curX+1,curY+1,curX+59,curY+59,0xFF110011, 0x00000000)
		rt_EchoOfBat = 601
	end
	movecursor()

	-- Force of Echo
	if RelicArray[3] ~= RelicArrayOld[3] then
		forms.drawBox(myPB,curX,curY,curX+59,curY+59,0xFF110011, 0xFF110011)	-- Clear to BG Color
		if RelicArray[3] > 0 then
			forms.drawImage(myPB,"Images/ForceOfEcho.png",curX,curY,60,60,true)
		else
			forms.drawImage(myPB,"Images/Dark_ForceOfEcho.png",curX,curY,60,60,true)		
		end
	end
	if rt_ForceOfEcho > 0 and rt_ForceOfEcho < 600 then
		forms.drawBox(myPB,curX+1,curY+1,curX+59,curY+59,0xFFfce803, 0x00000000)
	end
	if rt_ForceOfEcho > 0 and rt_ForceOfEcho == 600 then
		forms.drawBox(myPB,curX+1,curY+1,curX+59,curY+59,0xFF110011, 0x00000000)
		rt_ForceOfEcho = 601
	end
	movecursor()

	-- Soul of Wolf
	if RelicArray[6] ~= RelicArrayOld[6] then
		forms.drawBox(myPB,curX,curY,curX+59,curY+59,0xFF110011, 0xFF110011)	-- Clear to BG Color
		if RelicArray[6] > 0 then
			forms.drawImage(myPB,"Images/SoulOfWolf.png",curX,curY,60,60,true)
		else
			forms.drawImage(myPB,"Images/Dark_SoulOfWolf.png",curX,curY,60,60,true)		
		end
	end
	if rt_SoulOfWolf > 0 and rt_SoulOfWolf < 600 then
		forms.drawBox(myPB,curX+1,curY+1,curX+59,curY+59,0xFFfce803, 0x00000000)
	end
	if rt_SoulOfWolf > 0 and rt_SoulOfWolf == 600 then
		forms.drawBox(myPB,curX+1,curY+1,curX+59,curY+59,0xFF110011, 0x00000000)
		rt_SoulOfWolf = 601
	end
	movecursor()

	-- Power of Wolf
	if RelicArray[5] ~= RelicArrayOld[5] then
		forms.drawBox(myPB,curX,curY,curX+59,curY+59,0xFF110011, 0xFF110011)	-- Clear to BG Color
		if RelicArray[5] > 0 then
			forms.drawImage(myPB,"Images/PowerOfWolf.png",curX,curY,60,60,true)
		else
			forms.drawImage(myPB,"Images/Dark_PowerOfWolf.png",curX,curY,60,60,true)		
		end
	end
	if rt_PowerOfWolf > 0 and rt_PowerOfWolf < 600 then
		forms.drawBox(myPB,curX+1,curY+1,curX+59,curY+59,0xFFfce803, 0x00000000)
	end
	if rt_PowerOfWolf > 0 and rt_PowerOfWolf == 600 then
		forms.drawBox(myPB,curX+1,curY+1,curX+59,curY+59,0xFF110011, 0x00000000)
		rt_PowerOfWolf = 601
	end
	movecursor()

	-- Skill of Wolf
	if RelicArray[8] ~= RelicArrayOld[8] then
		forms.drawBox(myPB,curX,curY,curX+59,curY+59,0xFF110011, 0xFF110011)	-- Clear to BG Color
		if RelicArray[8] > 0 then
			forms.drawImage(myPB,"Images/SkillOfWolf.png",curX,curY,60,60,true)
		else
			forms.drawImage(myPB,"Images/Dark_SkillOfWolf.png",curX,curY,60,60,true)		
		end
	end
	if rt_SkillOfWolf > 0 and rt_SkillOfWolf < 600 then
		forms.drawBox(myPB,curX+1,curY+1,curX+59,curY+59,0xFFfce803, 0x00000000)
	end
	if rt_SkillOfWolf > 0 and rt_SkillOfWolf == 600 then
		forms.drawBox(myPB,curX+1,curY+1,curX+59,curY+59,0xFF110011, 0x00000000)
		rt_SkillOfWolf = 601
	end
	movecursor()

	-- Form of Mist
	if RelicArray[7] ~= RelicArrayOld[7] then
		forms.drawBox(myPB,curX,curY,curX+59,curY+59,0xFF110011, 0xFF110011)	-- Clear to BG Color
		if RelicArray[7] > 0 then
			forms.drawImage(myPB,"Images/FormOfMist.png",curX,curY,60,60,true)
		else
			forms.drawImage(myPB,"Images/Dark_FormOfMist.png",curX,curY,60,60,true)
		end
	end
	if rt_FormOfMist > 0 and rt_FormOfMist < 600 then
		forms.drawBox(myPB,curX+1,curY+1,curX+59,curY+59,0xFFfce803, 0x00000000)
	end
	if rt_FormOfMist > 0 and rt_FormOfMist == 600 then
		forms.drawBox(myPB,curX+1,curY+1,curX+59,curY+59,0xFF110011, 0x00000000)
		rt_FormOfMist = 601
	end
	movecursor()

	-- Power of Mist
	if RelicArray[10] ~= RelicArrayOld[10] then
		forms.drawBox(myPB,curX,curY,curX+59,curY+59,0xFF110011, 0xFF110011)	-- Clear to BG Color
		if RelicArray[10] > 0 then
			forms.drawImage(myPB,"Images/PowerOfMist.png",curX,curY,60,60,true)
		else
			forms.drawImage(myPB,"Images/Dark_PowerOfMist.png",curX,curY,60,60,true)
		end
	end
	if rt_PowerOfMist > 0 and rt_PowerOfMist < 600 then
		forms.drawBox(myPB,curX+1,curY+1,curX+59,curY+59,0xFFfce803, 0x00000000)
	end
	if rt_PowerOfMist > 0 and rt_PowerOfMist == 600 then
		forms.drawBox(myPB,curX+1,curY+1,curX+59,curY+59,0xFF110011, 0x00000000)
		rt_PowerOfMist = 601
	end
	movecursor()

	-- Gas Cloud
	if RelicArray[9] ~= RelicArrayOld[9] then
		forms.drawBox(myPB,curX,curY,curX+59,curY+59,0xFF110011, 0xFF110011)	-- Clear to BG Color
		if RelicArray[9] > 0 then
			forms.drawImage(myPB,"Images/GasCloud.png",curX,curY,60,60,true)
		else
			forms.drawImage(myPB,"Images/Dark_GasCloud.png",curX,curY,60,60,true)
		end
	end
	if rt_GasCloud > 0 and rt_GasCloud < 600 then
		forms.drawBox(myPB,curX+1,curY+1,curX+59,curY+59,0xFFfce803, 0x00000000)
	end
	if rt_GasCloud > 0 and rt_GasCloud == 600 then
		forms.drawBox(myPB,curX+1,curY+1,curX+59,curY+59,0xFF110011, 0x00000000)
		rt_GasCloud = 601
	end
	movecursor()

	-- Cube of Zoe
	if RelicArray[12] ~= RelicArrayOld[12] then
		forms.drawBox(myPB,curX,curY,curX+59,curY+59,0xFF110011, 0xFF110011)	-- Clear to BG Color
		if RelicArray[12] > 0 then
			forms.drawImage(myPB,"Images/CubeOfZoe.png",curX,curY,60,60,true)
		else
			forms.drawImage(myPB,"Images/Dark_CubeOfZoe.png",curX,curY,60,60,true)
		end
	end
	if rt_CubeOfZoe > 0 and rt_CubeOfZoe < 600 then
		forms.drawBox(myPB,curX+1,curY+1,curX+59,curY+59,0xFFfce803, 0x00000000)
	end
	if rt_CubeOfZoe > 0 and rt_CubeOfZoe == 600 then
		forms.drawBox(myPB,curX+1,curY+1,curX+59,curY+59,0xFF110011, 0x00000000)
		rt_CubeOfZoe = 601
	end
	movecursor()

	-- Spirit Orb
	if RelicArray[11] ~= RelicArrayOld[11] then
		forms.drawBox(myPB,curX,curY,curX+59,curY+59,0xFF110011, 0xFF110011)	-- Clear to BG Color
		if RelicArray[11] > 0 then
			forms.drawImage(myPB,"Images/SpiritOrb.png",curX,curY,60,60,true)
		else
			forms.drawImage(myPB,"Images/Dark_SpiritOrb.png",curX,curY,60,60,true)
		end
	end
	if rt_SpiritOrb > 0 and rt_SpiritOrb < 600 then
		forms.drawBox(myPB,curX+1,curY+1,curX+59,curY+59,0xFFfce803, 0x00000000)
	end
	if rt_SpiritOrb > 0 and rt_SpiritOrb == 600 then
		forms.drawBox(myPB,curX+1,curY+1,curX+59,curY+59,0xFF110011, 0x00000000)
		rt_SpiritOrb = 601
	end
	movecursor()

	-- Gravity Boots
	if RelicArray[14] ~= RelicArrayOld[14] then
		forms.drawBox(myPB,curX,curY,curX+59,curY+59,0xFF110011, 0xFF110011)	-- Clear to BG Color
		if RelicArray[14] > 0 then
			forms.drawImage(myPB,"Images/GravityBoots.png",curX,curY,60,60,true)
		else
			forms.drawImage(myPB,"Images/Dark_GravityBoots.png",curX,curY,60,60,true)
		end
	end
	if rt_GravityBoots > 0 and rt_GravityBoots < 600 then
		forms.drawBox(myPB,curX+1,curY+1,curX+59,curY+59,0xFFfce803, 0x00000000)
	end
	if rt_GravityBoots > 0 and rt_GravityBoots == 600 then
		forms.drawBox(myPB,curX+1,curY+1,curX+59,curY+59,0xFF110011, 0x00000000)
		rt_GravityBoots = 601
	end
	movecursor()

	-- Leap Stone
	if RelicArray[13] ~= RelicArrayOld[13] then
		forms.drawBox(myPB,curX,curY,curX+59,curY+59,0xFF110011, 0xFF110011)	-- Clear to BG Color
		if RelicArray[13] > 0 then
			forms.drawImage(myPB,"Images/LeapStone.png",curX,curY,60,60,true)
		else
			forms.drawImage(myPB,"Images/Dark_LeapStone.png",curX,curY,60,60,true)
		end
	end
	if rt_LeapStone > 0 and rt_LeapStone < 600 then
		forms.drawBox(myPB,curX+1,curY+1,curX+59,curY+59,0xFFfce803, 0x00000000)
	end
	if rt_LeapStone > 0 and rt_LeapStone == 600 then
		forms.drawBox(myPB,curX+1,curY+1,curX+59,curY+59,0xFF110011, 0x00000000)
		rt_LeapStone = 601
	end
	movecursor()

	-- Holy Symbol
	if RelicArray[16] ~= RelicArrayOld[16] then
		forms.drawBox(myPB,curX,curY,curX+59,curY+59,0xFF110011, 0xFF110011)	-- Clear to BG Color
		if RelicArray[16] > 0 then
			forms.drawImage(myPB,"Images/HolySymbol.png",curX,curY,60,60,true)
		else
			forms.drawImage(myPB,"Images/Dark_HolySymbol.png",curX,curY,60,60,true)
		end
	end
	if rt_HolySymbol > 0 and rt_HolySymbol < 600 then
		forms.drawBox(myPB,curX+1,curY+1,curX+59,curY+59,0xFFfce803, 0x00000000)
	end
	if rt_HolySymbol > 0 and rt_HolySymbol == 600 then
		forms.drawBox(myPB,curX+1,curY+1,curX+59,curY+59,0xFF110011, 0x00000000)
		rt_HolySymbol = 601
	end
	movecursor()

	-- FaerieScroll
	if RelicArray[15] ~= RelicArrayOld[15] then
		forms.drawBox(myPB,curX,curY,curX+59,curY+59,0xFF110011, 0xFF110011)	-- Clear to BG Color
		if RelicArray[15] > 2 then
			forms.drawImage(myPB,"Images/FaerieScroll.png",curX,curY,60,60,true)
		else
			forms.drawImage(myPB,"Images/Dark_FaerieScroll.png",curX,curY,60,60,true)
		end
	end
	if rt_FaerieScroll > 0 and rt_FaerieScroll < 600 then
		forms.drawBox(myPB,curX+1,curY+1,curX+59,curY+59,0xFFfce803, 0x00000000)
	end
	if rt_FaerieScroll > 0 and rt_FaerieScroll == 600 then
		forms.drawBox(myPB,curX+1,curY+1,curX+59,curY+59,0xFF110011, 0x00000000)
		rt_FaerieScroll = 601
	end
	movecursor()

	-- Jewel of Open
	if RelicArray[18] ~= RelicArrayOld[18] then
		forms.drawBox(myPB,curX,curY,curX+59,curY+59,0xFF110011, 0xFF110011)	-- Clear to BG Color
		if RelicArray[18] > 0 then
			forms.drawImage(myPB,"Images/JewelOfOpen.png",curX,curY,60,60,true)
		else
			forms.drawImage(myPB,"Images/Dark_JewelOfOpen.png",curX,curY,60,60,true)
		end
	end
	if rt_JewelOfOpen > 0 and rt_JewelOfOpen < 600 then
		forms.drawBox(myPB,curX+1,curY+1,curX+59,curY+59,0xFFfce803, 0x00000000)
	end
	if rt_JewelOfOpen > 0 and rt_JewelOfOpen == 600 then
		forms.drawBox(myPB,curX+1,curY+1,curX+59,curY+59,0xFF110011, 0x00000000)
		rt_JewelOfOpen = 601
	end
	movecursor()

	-- Merman Statue
	if RelicArray[17] ~= RelicArrayOld[17] then
		forms.drawBox(myPB,curX,curY,curX+59,curY+59,0xFF110011, 0xFF110011)	-- Clear to BG Color
		if RelicArray[17] > 0 then
			forms.drawImage(myPB,"Images/MermanStatue.png",curX,curY,60,60,true)
		else
			forms.drawImage(myPB,"Images/Dark_MermanStatue.png",curX,curY,60,60,true)
		end
	end
	if rt_MermanStatue > 0 and rt_MermanStatue < 600 then
		forms.drawBox(myPB,curX+1,curY+1,curX+59,curY+59,0xFFfce803, 0x00000000)
	end
	if rt_MermanStatue > 0 and rt_MermanStatue == 600 then
		forms.drawBox(myPB,curX+1,curY+1,curX+59,curY+59,0xFF110011, 0x00000000)
		rt_MermanStatue = 601
	end
	movecursor()

	-- Bat Card
	curX = 60
	if RelicArray[20] ~= RelicArrayOld[20] then
		forms.drawBox(myPB,curX,curY,curX+29,curY+29,0xFF110011, 0xFF110011)	-- Clear to BG Color
		if RelicArray[20] > 0 then
			forms.drawImage(myPB,"Images/BatCard.png",curX,curY,30,30,true)
		else
			forms.drawImage(myPB,"Images/Dark_BatCard.png",curX,curY,30,30,true)
		end
	end
	if rt_BatCard > 0 and rt_BatCard < 600 then
		forms.drawBox(myPB,curX+1,curY+1,curX+29,curY+29,0xFFfce803, 0x00000000)
	end
	if rt_BatCard > 0 and rt_BatCard == 600 then
		forms.drawBox(myPB,curX+1,curY+1,curX+29,curY+29,0xFF110011, 0x00000000)
		rt_BatCard = 601
	end
	curX = curX + 30

	-- Ghost Card
	if RelicArray[19] ~= RelicArrayOld[19] then
		forms.drawBox(myPB,curX,curY,curX+29,curY+29,0xFF110011, 0xFF110011)	-- Clear to BG Color
		if RelicArray[19] > 0 then
			forms.drawImage(myPB,"Images/GhostCard.png",curX,curY,30,30,true)
		else
			forms.drawImage(myPB,"Images/Dark_GhostCard.png",curX,curY,30,30,true)
		end
	end
	if rt_GhostCard > 0 and rt_GhostCard < 600 then
		forms.drawBox(myPB,curX+1,curY+1,curX+29,curY+29,0xFFfce803, 0x00000000)
	end
	if rt_GhostCard > 0 and rt_GhostCard == 600 then
		forms.drawBox(myPB,curX+1,curY+1,curX+29,curY+29,0xFF110011, 0x00000000)
		rt_GhostCard = 601
	end
	curX = curX + 30

	-- Faerie Card
	if RelicArray[22] ~= RelicArrayOld[22] then
		forms.drawBox(myPB,curX,curY,curX+29,curY+29,0xFF110011, 0xFF110011)	-- Clear to BG Color
		if RelicArray[22] > 0 then
			forms.drawImage(myPB,"Images/FaerieCard.png",curX,curY,30,30,true)
		else
			forms.drawImage(myPB,"Images/Dark_FaerieCard.png",curX,curY,30,30,true)
		end
	end
	if rt_FaerieCard > 0 and rt_FaerieCard < 600 then
		forms.drawBox(myPB,curX+1,curY+1,curX+29,curY+29,0xFFfce803, 0x00000000)
	end
	if rt_FaerieCard > 0 and rt_FaerieCard == 600 then
		forms.drawBox(myPB,curX+1,curY+1,curX+29,curY+29,0xFF110011, 0x00000000)
		rt_FaerieCard = 601
	end
	curX = curX + 30

	-- Demon Card
	if RelicArray[21] ~= RelicArrayOld[21] then
		forms.drawBox(myPB,curX,curY,curX+29,curY+29,0xFF110011, 0xFF110011)	-- Clear to BG Color
		if RelicArray[21] > 0 then
			forms.drawImage(myPB,"Images/DemonCard.png",curX,curY,30,30,true)
		else
			forms.drawImage(myPB,"Images/Dark_DemonCard.png",curX,curY,30,30,true)
		end
	end
	if rt_DemonCard > 0 and rt_DemonCard < 600 then
		forms.drawBox(myPB,curX+1,curY+1,curX+29,curY+29,0xFFfce803, 0x00000000)
	end
	if rt_DemonCard > 0 and rt_DemonCard == 600 then
		forms.drawBox(myPB,curX+1,curY+1,curX+29,curY+29,0xFF110011, 0x00000000)
		rt_DemonCard = 601
	end
	curX = curX + 30

	-- Sword Card
	if RelicArray[24] ~= RelicArrayOld[24] then
		forms.drawBox(myPB,curX,curY,curX+29,curY+29,0xFF110011, 0xFF110011)	-- Clear to BG Color
		if RelicArray[24] > 0 then
			forms.drawImage(myPB,"Images/SwordCard.png",curX,curY,30,30,true)
		else
			forms.drawImage(myPB,"Images/Dark_SwordCard.png",curX,curY,30,30,true)
		end
	end
	if rt_SwordCard > 0 and rt_SwordCard < 600 then
		forms.drawBox(myPB,curX+1,curY+1,curX+29,curY+29,0xFFfce803, 0x00000000)
	end
	if rt_SwordCard > 0 and rt_SwordCard == 600 then
		forms.drawBox(myPB,curX+1,curY+1,curX+29,curY+29,0xFF110011, 0x00000000)
		rt_SwordCard = 601
	end
	curX = curX + 30

	-- Sprite Card
	if RelicArray[23] ~= RelicArrayOld[23] then
		forms.drawBox(myPB,curX,curY,curX+29,curY+29,0xFF110011, 0xFF110011)	-- Clear to BG Color
		if RelicArray[23] > 0 then
			forms.drawImage(myPB,"Images/SpriteCard.png",curX,curY,30,30,true)
		else
			forms.drawImage(myPB,"Images/Dark_SpriteCard.png",curX,curY,30,30,true)
		end
	end
	if rt_SpriteCard > 0 and rt_SpriteCard < 600 then
		forms.drawBox(myPB,curX+1,curY+1,curX+29,curY+29,0xFFfce803, 0x00000000)
	end
	if rt_SpriteCard > 0 and rt_SpriteCard == 600 then
		forms.drawBox(myPB,curX+1,curY+1,curX+29,curY+29,0xFF110011, 0x00000000)
		rt_SpriteCard = 601
	end
	curX = curX + 30

	-- NoseDevil Card
	if RelicArray[26] ~= RelicArrayOld[26] then
		forms.drawBox(myPB,curX,curY,curX+29,curY+29,0xFF110011, 0xFF110011)	-- Clear to BG Color
		if RelicArray[26] > 0 then
			forms.drawImage(myPB,"Images/NoseDevilCard.png",curX,curY,30,30,true)
		else
			forms.drawImage(myPB,"Images/Dark_NoseDevilCard.png",curX,curY,30,30,true)
		end
	end
	if rt_NoseDevilCard > 0 and rt_NoseDevilCard < 600 then
		forms.drawBox(myPB,curX+1,curY+1,curX+29,curY+29,0xFFfce803, 0x00000000)
	end
	if rt_NoseDevilCard > 0 and rt_NoseDevilCard == 600 then
		forms.drawBox(myPB,curX+1,curY+1,curX+29,curY+29,0xFF110011, 0x00000000)
		rt_NoseDevilCard = 601
	end
	curX = 0
	curY = curY + 30

	-- Heart of Vlad
	if RelicArray[25] ~= RelicArrayOld[25] then
		forms.drawBox(myPB,curX,curY,curX+59,curY+59,0xFF110011, 0xFF110011)	-- Clear to BG Color
		if RelicArray[25] > 0 then
			forms.drawImage(myPB,"Images/HeartOfVlad.png",curX,curY,60,60,true)
		else
			forms.drawImage(myPB,"Images/Dark_HeartOfVlad.png",curX,curY,60,60,true)		
		end
	end
	if rt_HeartOfVlad > 0 and rt_HeartOfVlad < 600 then
		forms.drawBox(myPB,curX+1,curY+1,curX+59,curY+59,0xFFfce803, 0x00000000)
	end
	if rt_HeartOfVlad > 0 and rt_HeartOfVlad == 600 then
		forms.drawBox(myPB,curX+1,curY+1,curX+59,curY+59,0xFF110011, 0x00000000)
		rt_HeartOfVlad = 601
	end
	movecursor()
	
	-- Tooth of Vlad
	if RelicArray[28] ~= RelicArrayOld[28] then
		forms.drawBox(myPB,curX,curY,curX+59,curY+59,0xFF110011, 0xFF110011)	-- Clear to BG Color
		if RelicArray[28] > 0 then
			forms.drawImage(myPB,"Images/ToothOfVlad.png",curX,curY,60,60,true)
		else
			forms.drawImage(myPB,"Images/Dark_ToothOfVlad.png",curX,curY,60,60,true)
		end
	end
	if rt_ToothOfVlad > 0 and rt_ToothOfVlad < 600 then
		forms.drawBox(myPB,curX+1,curY+1,curX+59,curY+59,0xFFfce803, 0x00000000)
	end
	if rt_ToothOfVlad > 0 and rt_ToothOfVlad == 600 then
		forms.drawBox(myPB,curX+1,curY+1,curX+59,curY+59,0xFF110011, 0x00000000)
		rt_ToothOfVlad = 601
	end
	movecursor()

	-- Rib of Vlad
	if RelicArray[27] ~= RelicArrayOld[27] then
		forms.drawBox(myPB,curX,curY,curX+59,curY+59,0xFF110011, 0xFF110011)	-- Clear to BG Color
		if RelicArray[27] > 0 then
			forms.drawImage(myPB,"Images/RibOfVlad.png",curX,curY,60,60,true)
		else
			forms.drawImage(myPB,"Images/Dark_RibOfVlad.png",curX,curY,60,60,true)
		end
	end
	if rt_RibOfVlad > 0 and rt_RibOfVlad < 600 then
		forms.drawBox(myPB,curX+1,curY+1,curX+59,curY+59,0xFFfce803, 0x00000000)
	end
	if rt_RibOfVlad > 0 and rt_RibOfVlad == 600 then
		forms.drawBox(myPB,curX+1,curY+1,curX+59,curY+59,0xFF110011, 0x00000000)
		rt_RibOfVlad = 601
	end
	movecursor()

	-- Ring of Vlad
	if RelicArray[30] ~= RelicArrayOld[30] then
		forms.drawBox(myPB,curX,curY,curX+59,curY+59,0xFF110011, 0xFF110011)	-- Clear to BG Color
		if RelicArray[30] > 0 then
			forms.drawImage(myPB,"Images/RingOfVlad.png",curX,curY,60,60,true)
		else
			forms.drawImage(myPB,"Images/Dark_RingOfVlad.png",curX,curY,60,60,true)
		end
	end
	if rt_RingOfVlad > 0 and rt_RingOfVlad < 600 then
		forms.drawBox(myPB,curX+1,curY+1,curX+59,curY+59,0xFFfce803, 0x00000000)
	end
	if rt_RingOfVlad > 0 and rt_RingOfVlad == 600 then
		forms.drawBox(myPB,curX+1,curY+1,curX+59,curY+59,0xFF110011, 0x00000000)
		rt_RingOfVlad = 601
	end
	movecursor()

	-- Eye of Vlad
	if RelicArray[29] ~= RelicArrayOld[29] then
		forms.drawBox(myPB,curX,curY,curX+59,curY+59,0xFF110011, 0xFF110011)	-- Clear to BG Color
		if RelicArray[29] > 0 then
			forms.drawImage(myPB,"Images/EyeOfVlad.png",curX,curY,60,60,true)
		else
			forms.drawImage(myPB,"Images/Dark_EyeOfVlad.png",curX,curY,60,60,true)
		end
	end
	if rt_EyeOfVlad > 0 and rt_EyeOfVlad < 600 then
		forms.drawBox(myPB,curX+1,curY+1,curX+59,curY+59,0xFFfce803, 0x00000000)
	end
	if rt_EyeOfVlad > 0 and rt_EyeOfVlad == 600 then
		forms.drawBox(myPB,curX+1,curY+1,curX+59,curY+59,0xFF110011, 0x00000000)
		rt_EyeOfVlad = 601
	end
	movecursor()

	-- Forces Vlads on top row by themselves.
	--curX = 0
	--curY = 60







	movecursor()

	-- Forces Key Items on 2nd row by themselves.
	--curX = 0
	--curY = 120

	if kiu_GoldRing > 0 then
		if ki_GoldRing > 0 then
			forms.drawImage(myPB,"Images/GoldRing.png",curX,curY,60,60,true)
		else
			forms.drawImage(myPB,"Images/Dark_GoldRing.png",curX,curY,60,60,true)
		end
	end
	movecursor()
	if kiu_SilverRing > 0 then
		if ki_SilverRing > 0 then
			forms.drawImage(myPB,"Images/SilverRing.png",curX,curY,60,60,true)
		else
			forms.drawImage(myPB,"Images/Dark_SilverRing.png",curX,curY,60,60,true)
		end
	end
	movecursor()

	if kiu_HolyGlasses > 0 then
		if ki_HolyGlasses > 0 or memory.read_u8(0x5C9AE,"Work Ram High") == 0x22 then
			forms.drawImage(myPB,"Images/HolyGlasses.png",curX,curY,60,60,true)
		else
			forms.drawImage(myPB,"Images/Dark_HolyGlasses.png",curX,curY,60,60,true)
		end
	end
	movecursor()

	if kiu_SpikeBreaker > 0 then
		if ki_SpikeBreaker > 0 or memory.read_u8(0x5C9B2,"Work Ram High") == 0x0E then
			forms.drawImage(myPB,"Images/Spikebreaker.png",curX,curY,60,60,true)
		else
			forms.drawImage(myPB,"Images/Dark_Spikebreaker.png",curX,curY,60,60,true)
		end
	end
	movecursor()

	if kiu_LibraryCard > 0 then
		if ki_LibraryCard > 0 then
			forms.drawImage(myPB,"Images/LibraryCard.png",curX,curY,60,60,true)
		else
			forms.drawImage(myPB,"Images/Dark_LibraryCard.png",curX,curY,60,60,true)
		end
	end
	movecursor()

	-- God Speed Shoes
	if RelicArray[32] ~= RelicArrayOld[32] then
		forms.drawBox(myPB,curX,curY,curX+59,curY+59,0xFF110011, 0xFF110011)	-- Clear to BG Color
		if RelicArray[32] > 0 then
			forms.drawImage(myPB,"Images/GodSpeedShoes.png",curX,curY,60,60,true)
		else
			forms.drawImage(myPB,"Images/Dark_GodSpeedShoes.png",curX,curY,60,60,true)
		end
	end
	if rt_GodSpeedShoes > 0 and rt_GodSpeedShoes < 600 then
		forms.drawBox(myPB,curX+1,curY+1,curX+59,curY+59,0xFFfce803, 0x00000000)
	end
	if rt_GodSpeedShoes > 0 and rt_GodSpeedShoes == 600 then
		forms.drawBox(myPB,curX+1,curY+1,curX+59,curY+59,0xFF110011, 0x00000000)
		rt_GodSpeedShoes = 601
	end
	movecursor()


	--forms.drawText(myPB,0,200,"Time:" .. curHour .. curMin,0xFFFFFFFF,0xFF000000, 16)
	buildtimestr()
	if(RunEndFrame == 0 and RunStartFrame > 0) then
		--forms.drawText(myPB,0,342,timestr,0xFFFFFFFF,0xFF000000, 16)
	end

	buildautotimestr()
	forms.drawText(myPB,0,344,timestr,0xFFFFFFFF,0xFF000000, 20)

	--forms.drawImage(myPB,"Images/Castle1_Empty_TP.png",400,0,320,255,true)
	
	GetSeedTimeName()

	forms.refresh(myPB)
end

function DrawMapTrackerText()
	forms.drawText(myPB,4,490,"RESET!",0xFFFF0000,16)
	forms.drawText(myPB,104,490,"Change Map Size",0xFFFFFFFF,16)

	forms.drawBox(myPB,230,490,400,510,0xFF000000, 0xFF000000)
	if(checkset == 0) then forms.drawText(myPB,230,490,"RelicOnly Checks",0xFF00FF00,16) end
	if(checkset == 1) then forms.drawText(myPB,230,490,"Relic+KeyItem Checks",0xFF00FF00,16) end
	if(checkset == 2) then forms.drawText(myPB,230,490,"Guarded Checks",0xFF00FF00,16) end
	if(checkset == 3) then forms.drawText(myPB,230,490,"Saturn Checks",0xFF00FF00,16) end
	if(checkset == 4) then forms.drawText(myPB,230,490,"Maximum Checks",0xFF00FF00,16) end
end

function DoCastleMap()

local stringbufA
local stringbufB
local drawX
local drawY
local NewCastle

castleX = memory.read_u8(0x5CE6A)
castleY = memory.read_u8(0x5CE6E)
roomX = memory.read_u16_le(0x05CD5A)
roomY = memory.read_u16_le(0x05C5B6)

roomX = math.floor(roomX/320)
roomY = math.floor(roomY/256)

castleX = castleX+roomX
castleY = castleY+roomY




--[[
stringbufA = bizstring.hex(castleX)
stringbufB = bizstring.hex(castleY)
print(stringbufA .. "," .. stringbufB)
]]--

	-- Find which castle we are currently in.
	NewCastle = bit.band(memory.read_u8(0x5D750),0x20)
	if(NewCastle == 0x20) then
		NewCastle = 2
	end
	if(NewCastle == 0x00) then
		NewCastle = 1
	end

	-- Update which Castle we are in if we changed.
	if(NewCastle ~= lastCastleRedraw) then
		curCastle = NewCastle
		ChangeCastle()
		lastCastleRedraw = NewCastle
	end

	-- Castle Entrance, Don't log before entering the Gate.
	if(zone == 0x41 and (castleY >=46 or castleX<2) ) then return end
	-- Don't log during Prologue or Final Dracula
	if(zone == 0x1F or zone == 0x38) then return end

	-- If we aren't in Gameplay, don't Update Map Progress
	if(memory.read_u8(0x5CD70) ~= 5) then
		--PreviousY = -10
		--PreviousCastleY = -1
		return
	end

	-- Adjust Y Position for Castle 2
	if(curCastle == 2) then castleY = castleY - 7 end

	-- Calculate Drawing Position
	drawX = 400 + (castleX * (5*mapsize) )
	drawY = (castleY * (5*mapsize)) - (15 * mapsize)

	-- Normal No Map Position Cursor
	if(ShowMapPos == 0) then
		if(mapsize == 1) then
			forms.drawBox(myPB,drawX,drawY,drawX+4,drawY+4,0xFF0000E0, 0xFF00000E0)
			if(curCastle == 1) then	forms.drawImageRegion(myPB,"Images/Castle1_Empty_TP.png",castleX * 5,(castleY*5) - 15,5,5,drawX,drawY,5,5) end
			if(curCastle == 2) then	forms.drawImageRegion(myPB,"Images/Castle2_Empty_TP.png",castleX * 5,(castleY*5) - 15,5,5,drawX,drawY,5,5) end
		end
		if(mapsize == 2) then 
			forms.drawBox(myPB,drawX,drawY,drawX+9,drawY+9,0xFF0000E0, 0xFF00000E0)
			if(curCastle == 1) then forms.drawImageRegion(myPB,"Images/Castle1_Empty_TP.png",castleX * 5,(castleY*5) - 15,5,5,drawX,drawY,10,10) end
			if(curCastle == 2) then forms.drawImageRegion(myPB,"Images/Castle2_Empty_TP.png",castleX * 5,(castleY*5) - 15,5,5,drawX,drawY,10,10) end
		end
	end
	if ShowMapPos > 0 then
	-- Show Map Position Cursor
		-- Update Previous Square. This will be blue.
		if(mapsize == 1) then
			forms.drawBox(myPB,PreviousX,PreviousY,PreviousX+4,PreviousY+4,0xFF0000E0, 0xFF00000E0)
			if(curCastle == 1) then	forms.drawImageRegion(myPB,"Images/Castle1_Empty_TP.png",PreviousCastleX * 5,(PreviousCastleY*5) - 15,5,5,PreviousX,PreviousY,5,5) end
			if(curCastle == 2) then	forms.drawImageRegion(myPB,"Images/Castle2_Empty_TP.png",PreviousCastleX * 5,(PreviousCastleY*5) - 15,5,5,PreviousX,PreviousY,5,5) end
		end
		if(mapsize == 2) then
			forms.drawBox(myPB,PreviousX,PreviousY,PreviousX+9,PreviousY+9,0xFF0000E0, 0xFF00000E0)
			if(curCastle == 1) then forms.drawImageRegion(myPB,"Images/Castle1_Empty_TP.png",PreviousCastleX * 5,(PreviousCastleY*5) - 15,5,5,PreviousX,PreviousY,10,10) end
			if(curCastle == 2) then forms.drawImageRegion(myPB,"Images/Castle2_Empty_TP.png",PreviousCastleX * 5,(PreviousCastleY*5) - 15,5,5,PreviousX,PreviousY,10,10) end
		end
		PreviousX = drawX
		PreviousY = drawY
		PreviousCastleX = castleX
		PreviousCastleY = castleY
		
		-- End of Previous Square Update

		-- Update Current Square. This will be Pink.
		if(mapsize == 1) then
			forms.drawBox(myPB,drawX,drawY,drawX+4,drawY+4,0xFFE000E0, 0xFFE000E0)
			if(curCastle == 1) then	forms.drawImageRegion(myPB,"Images/Castle1_Empty_TP.png",castleX * 5,(castleY*5) - 15,5,5,drawX,drawY,5,5) end
			if(curCastle == 2) then	forms.drawImageRegion(myPB,"Images/Castle2_Empty_TP.png",castleX * 5,(castleY*5) - 15,5,5,drawX,drawY,5,5) end
		end
		if(mapsize == 2) then 
			forms.drawBox(myPB,drawX,drawY,drawX+9,drawY+9,0xFFE000E0, 0xFFE000E0)
			if(curCastle == 1) then forms.drawImageRegion(myPB,"Images/Castle1_Empty_TP.png",castleX * 5,(castleY*5) - 15,5,5,drawX,drawY,10,10) end
			if(curCastle == 2) then forms.drawImageRegion(myPB,"Images/Castle2_Empty_TP.png",castleX * 5,(castleY*5) - 15,5,5,drawX,drawY,10,10) end
		end
	end



	-- Mark Map Location
	if(curCastle == 1) then
		rec_map1[castleX + (castleY*64)] = 1
	end
	if(curCastle == 2) then
		rec_map2[castleX + (castleY*64)] = 1
	end
--[[
if(mapsize == 3) then
	mapsize = 1
	forms.drawImage(myPB,"Images/Castle1_Empty_TP.png",400,0,320*mapsize,255*mapsize,true)
end
if(mapsize == 4) then
	mapsize = 2
	forms.drawImage(myPB,"Images/Castle1_Empty_TP.png",400,0,320*mapsize,255*mapsize,true)
end
]]--

end

function ChangeCastle()

	-- Clear Canvas
	forms.drawBox(myPB,372,0,372+742,290+120+500, 0xFF000000, 0xFF000000)

	-- Draw Castle Progress
	if(curCastle == 1) then
		for x=0, 63 do
			for y=0, 63 do
				if(mapsize == 2) then
					if(rec_map1[x + (y*64)] == 1) then
						forms.drawBox(myPB,400 + (x*10),(y*10) - 30,409 + (x*10),(y*10) - 21,0xFF0000E0, 0xFF0000E0)
					end
				end
				if(mapsize == 1) then
					if(rec_map1[x + (y*64)] == 1) then
						forms.drawBox(myPB,400 + (x*5),(y*5) - 15,404 + (x*5),(y*5) - 11,0xFF0000E0, 0xFF0000E0)
					end
				end
				-- Draw Checks
				if(mapsize == 2) then
					if(rec_map1[x + (y*64)] == 2) then
						forms.drawBox(myPB,400 + (x*10),(y*10) - 30,408 + (x*10),(y*10) - 22,0xFF00FF00, 0xFF00FF00)
					end
				end
				if(mapsize == 1) then
					if(rec_map1[x + (y*64)] == 2) then
						forms.drawBox(myPB,400 + (x*5),(y*5) - 15,404 + (x*5),(y*5) - 11,0xFF00FF00, 0xFF00FF00)
					end
				end
			end
		end
	end
	if(curCastle == 2) then
		for x=0, 63 do
			for y=0, 63 do
				if(mapsize == 2) then
					if(rec_map2[x + (y*64)] == 1) then
						forms.drawBox(myPB,400 + (x*10),(y*10) - 30,409 + (x*10),(y*10) - 21,0xFF0000E0, 0xFF0000E0)
					end
				end
				if(mapsize == 1) then
					if(rec_map2[x + (y*64)] == 1) then
						forms.drawBox(myPB,400 + (x*5),(y*5) - 15,404 + (x*5),(y*5) - 11,0xFF0000E0, 0xFF0000E0)
					end
				end
				-- Draw Checks
				if(mapsize == 2) then
					if(rec_map2[x + (y*64)] == 2) then
						forms.drawBox(myPB,400 + (x*10),(y*10) - 30,408 + (x*10),(y*10) - 22,0xFF00FF00, 0xFF00FF00)
					end
				end
				if(mapsize == 1) then
					if(rec_map2[x + (y*64)] == 2) then
						forms.drawBox(myPB,400 + (x*5),(y*5) - 15,404 + (x*5),(y*5) - 11,0xFF00FF00, 0xFF00FF00)
					end
				end
			end
		end
	end

	-- Draw Castle Outline
	if(curCastle == 1) then
		if(mapsize == 1) then
			forms.drawImage(myPB,"Images/Castle1_Empty_TP.png",400,0,320*mapsize,255*mapsize,true)
		end
		if(mapsize == 2) then
			forms.drawImage(myPB,"Images/Castle1_Empty_TP.png",400,0,320*mapsize,255*mapsize,true)
		end
	end
	if(curCastle == 2) then
		if(mapsize == 1) then
			forms.drawImage(myPB,"Images/Castle2_Empty_TP.png",400,0,320*mapsize,255*mapsize,true)
		end
		if(mapsize == 2) then
			forms.drawImage(myPB,"Images/Castle2_Empty_TP.png",400,0,320*mapsize,255*mapsize,true)
		end
	end


	-- remove this later
	forms.refresh(myPB)
end


function PictureBoxClick()
	WX = forms.getMouseX(myPB)
	WY = forms.getMouseY(myPB)

	-- Clicked Map Size
	if(WX>104 and WX<220 and WY>490) then
		mapsize = mapsize + 1
		if(mapsize>=3) then mapsize = 1 end
		-- Stop Position Logging for one Instance due to Map Size Change.
		PreviousY = -10
		PreviousCastleY = -1		
		ChangeCastle()
	end

	-- Clicked Reset
	if(WX<44 and WY>490) then
		RunStartFrame = 0
		SeedName = ""

		for i=0, 4096 do
			rec_map1[i] = 0
			rec_map2[i] = 0
		end
		RelicChecks()
		if(checkset>=1) then KeyItemChecks() end
		if(checkset>=2) then GuardedChecks() end
		if(checkset>=3) then SaturnChecks() end
		if(checkset>=4) then MaximumChecks() end
		ChangeCastle()
	end
	-- Clicked CheckSet Change
	if(WX>230 and WX<300 and WY>490) then
		for i=0, 4096 do
			if(rec_map1[i] == 2) then rec_map1[i] = 0 end
			if(rec_map2[i] == 2) then rec_map2[i] = 0 end
		end
		checkset = checkset + 1
		if(checkset>4) then checkset = 0 end
		RelicChecks()
		if(checkset>=1) then KeyItemChecks() end
		if(checkset>=2) then GuardedChecks() end
		if(checkset>=3) then SaturnChecks() end
		if(checkset>=4) then MaximumChecks() end
		ChangeCastle()
		DrawMapTrackerText()
	end
end

function AddCheckpx(posX,posY,castlenum)
	posX = math.floor(posX / 5)
	posY = posY + 15
	posY = math.floor(posY / 5)

	if(castlenum == 1) then rec_map1[ posX + (posY * 64) ] = 2 end
	if(castlenum == 2) then rec_map2[ posX + (posY * 64) ] = 2 end
end

function RelicChecks()
AddCheckpx(240,90,1)	-- Soul of Bat
AddCheckpx(295,40,1)	-- Fire of Bat
AddCheckpx(80,65,1)	-- Echo of Bat
AddCheckpx(40,60,2)	-- Force of Echo
AddCheckpx(305,75,1)	-- Soul of Wolf
AddCheckpx(15,175,1)	-- Power of Wolf
AddCheckpx(75,150,1)	-- Skill of Wolf
AddCheckpx(105,95,1)	-- Form of Mist
AddCheckpx(155,30,1)	-- Power of Mist
AddCheckpx(230,15,2)	-- Gas Cloud
AddCheckpx(95,165,1)	-- Cube of Zoe
AddCheckpx(125,145,1)	-- Spirit Orb
AddCheckpx(170,100,1)	-- Gravity Boots
AddCheckpx(155,40,1)	-- Leap Stone
AddCheckpx(275,190,1)	-- Holy Symbol
AddCheckpx(295,75,1)	-- Faerie Scroll
AddCheckpx(245,85,1)	-- Jewel of Open
AddCheckpx(40,195,1)	-- Merman Statue
AddCheckpx(65,120,1)	-- Bat Card
AddCheckpx(195,20,1)	-- Ghost Card
AddCheckpx(260,75,1)	-- Faerie Card
AddCheckpx(145,205,1)	-- Demon Card
AddCheckpx(165,75,1)	-- Sword Card
AddCheckpx(100,75,1)	-- Sprite Card
AddCheckpx(95,85,1)	-- Nosedevil Card
AddCheckpx(195,200,2)	-- Heart of Vlad
AddCheckpx(25,150,2)	-- Tooth of Vlad
AddCheckpx(220,185,2)	-- Rib of Vlad
AddCheckpx(115,215,2)	-- Ring of Vlad
AddCheckpx(160,65,2)	-- Eye of Vlad
end

function KeyItemChecks()
AddCheckpx(225,150,1)	-- Gold Ring
AddCheckpx(40,60,1)	-- Silver Ring
AddCheckpx(160,120,1)	-- Holy Glasses
AddCheckpx(205,240,1)	-- Spikebreaker
end

function GuardedChecks()
AddCheckpx(85,235,1)	-- Mormegil
AddCheckpx(200,175,1)	-- Crystal Cloak
AddCheckpx(115,75,2)	-- Dark Blade
AddCheckpx(215,155,2)	-- Trio
AddCheckpx(250,130,2)	-- Ring of Arcana
end

function SaturnChecks()
AddCheckpx(160,25,1)	-- God Speed Shoes
AddCheckpx(255,30,1)	-- Rainbow Mantle
AddCheckpx(105,205,1)	-- Garden Boss
AddCheckpx(30,205,1)	-- Pencil Board
AddCheckpx(165,160,1)	-- Astral Dagger
AddCheckpx(175,165,1)	-- Smelly Rice
AddCheckpx(140,85,2)	-- Delicious Meal
AddCheckpx(210,45,2)	-- Alucard Spear
end

function MaximumChecks()
AddCheckpx(55,175,2)	-- Reverse Faerie Card
AddCheckpx(65,175,2)	-- Badelaire
AddCheckpx(170,45,2)	-- Alucard Sword
AddCheckpx(70,165,2)	-- Reverse Shop
AddCheckpx(295,120,1)	-- Jewel Knuckle
end

function ReadSeedTimeName()
	local letter = 0x41
	local offset = 0x3BA9C

	while letter > 0 do
		letter = memory.read_u8( bit.bxor(offset,1) )
		if(letter > 0) then
			SeedTime = SeedTime .. string.char(letter)
		end
		offset = offset + 1
	end

	offset = 0x3BACC
	letter = 0x41

	while letter > 0 do
		letter = memory.read_u8( bit.bxor(offset,1) )
		if(letter > 0) then
			SeedName = SeedName .. string.char(letter)
		end
		offset = offset + 1
	end
	
end

function GetSeedTimeName()
	if(SeedName == "") then
		if(memory.read_u16_le(0x3BABE) == 0x2053) then
			ReadSeedTimeName()
		end
		if(bizstring.contains(SeedName,"1996")) then
			SeedName = "Vanilla Game"
			SeedTime = "1998"
		end

		forms.drawText(myPB,0,400,"Seed Name:" .. SeedName,0xFFFFFFFF,0xFF000000, 20)
		forms.drawText(myPB,0,422,"CreatedOn:" .. SeedTime,0xFFEEEEEE,0xFF000000, 16)
	end

end

-- Castle Map Test
forms.drawBox(myPB,372,0,372+742,290+120+500, 0xFF000000, 0xFF000000)
--forms.drawImage(myPB,"Images/Castle1_Empty_TP.png",400,0,320,255,true)


-- Add Event
forms.addclick(myPB,PictureBoxClick)

-- Add Checks
RelicChecks()
if(checkset>=1) then KeyItemChecks() end
if(checkset>=2) then GuardedChecks() end
if(checkset>=3) then SaturnChecks() end
if(checkset>=4) then MaximumChecks() end

DrawMapTrackerText()

-- Fix Annoying Warning Messages on Bizhawk 2.9 and above.
BizVersion = client.getversion()
if(bizstring.contains(BizVersion,"2.9")) then
	bit = (require "migration_helpers").EmuHawk_pre_2_9_bit();
end


while EndScript == false do -- The main cycle that causes the emulator to advance and trigger a game switch.
	--[[
	updatefc = updatefc + 1
	if (updatefc >= 60) then
		updatetracker()
		updatefc = 0
	end
	]]--
	updatetracker()

	updatemap = updatemap + 1
	if(updatemap >= 31) then
		DoCastleMap()
		updatemap = 0
	end

	autotimer()

	emu.frameadvance()
	
end

