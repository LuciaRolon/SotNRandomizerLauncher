--[[
	Castlevania SotN - Richter Randomizer Item Tracker
	By MottZilla
	Version: 2024, June 11th
	Many Images taken from https://github.com/TalicZealot/SotN-Relic-Tracker
]]--

titlestr = "Richter Tracker - June 11th 2024"
EndScript = false	-- Terminate Script Flag
NoItemCrash = 0		-- No Item Crashes Mode
PowerUpsEnable = 1	-- Richter Ability PowerUps Enable
TipsEnable = 1
updatefc = 0
curX = 0
curY = 0
perRow = 5
curHour = 0
curMin = 0
curSecs = 0
timestr = "Time - 00:00"
RunStartFrame = 0
RunEndFrame = 0
NoItemCrash = 0
MapUpdateZone = 64
workstr = ""
CardStr1 = "???"
CardStr2 = "???"
CardStr3 = "???"
CardStr4 = "???"
CardStr5 = "???"

TipCounter = 0
Pre_POW = 0
Cur_POW = 0
Pre_SOW = 0
Cur_SOW = 0
Pre_POM = 0
Cur_POM = 0
Pre_FS = 0
Cur_FS = 0

-- Castle Check Coords
c1r_x = {  13, 77,101, 61, 53, 33, 85, 33, 65, 81,125,125,157,237,245,237,209,197,193,137,129,181,161,221,117, 69,165}
c1r_y = { 133,125,109,113, 89, 41, 69,149, 45, 53, 25, 17,  9, 25, 53, 53, 53, 61, 65, 73,105,113,133,145,157,181,185}
c2r_x = { 161, 97,233, 81, 81, 53,161,221,121, 69}
c2r_y = {  21, 33, 73, 45, 69, 89,133,145,141,181}
maptracker_en = 1

-- Map Tracker Code Begins here
function DrawPix(xloc,yloc)
local vptr
local pixel
	vptr = 0x8A680
	vptr = vptr + (xloc/2) + (yloc * 0x800)
	pixel = memory.read_u8(vptr,"GPURAM")
	if(bit.band(xloc,1) == 1) then
		pixel = bit.band(pixel,0x0F)
		pixel = bit.bor(pixel,0x70)
	end
	if(bit.band(xloc,1) == 0) then
		pixel = bit.band(pixel,0xF0)
		pixel = bit.bor(pixel,0x07)
	end

	--console.log(bizstring.hex(vptr))
	memory.write_u8(vptr,pixel,"GPURAM")
end

function DrawBox(xloc,yloc)
local x,y
	for x = 0,2,1 do
		for y = 0,2,1 do
			DrawPix(xloc+x,yloc+y)
		end
	end
end

function UpdateMap()
	if(maptracker_en == 0) then return end
	zone = memory.read_u8(0x974A0)

	if(zone == 0x45) then
		MapUpdateZone = 64
		return
	end
	
	if(memory.read_u8(0x3C9A4) == 0x14) then

	if(MapUpdateZone == zone) then return end
	MapUpdateZone = zone
	for n = 1, 30,1
	do
		if( bit.band(zone,0x20) == 0) then		-- If Castle 1
			if(c1r_x[n] == nil) then break end
			DrawBox(c1r_x[n],c1r_y[n])
		end

		if( bit.band(zone,0x20) == 0x20) then		-- If Castle 2
			if(c2r_x[n] == nil) then break end
			DrawBox(c2r_x[n],c2r_y[n])
		end
	end
		
	end	-- EndIf 3C9A4 == 0x14
end
-- Map Tracker Stuff ^^


function closewindow()
	forms.destroyall()
	console.log("Window Closed!")
	EndScript = true
end

function subwptoggle()
	if(RunStartFrame>0) then return end	-- Can't Toggle after Run Begins
	NoItemCrash = NoItemCrash + 1
	if(NoItemCrash > 1) then NoItemCrash = 0 end
	if(NoItemCrash == 0) then forms.settext(NoItemCrashButton,"ItemCrash On") end
	if(NoItemCrash == 1) then forms.settext(NoItemCrashButton,"ItemCrash Off") end
end

function maptrackertoggle()
	--if(RunStartFrame>0) then return end	-- Can't Toggle after Run Begins
	maptracker_en = maptracker_en + 1
	if(maptracker_en > 1) then maptracker_en = 0 end
	if(maptracker_en == 1) then forms.settext(MapTrackerEnableButton,"Map Tracker On") end
	if(maptracker_en == 0) then forms.settext(MapTrackerEnableButton,"Map Tracker Off") end
end

function powerupstoggle()
	if(RunStartFrame>0) then return end	-- Can't Toggle after Run Begins
	PowerUpsEnable = PowerUpsEnable + 1
	if(PowerUpsEnable > 1) then PowerUpsEnable = 0 end
	if(PowerUpsEnable == 1) then forms.settext(PowerUpsEnableButton,"PowerUps On") end
	if(PowerUpsEnable == 0) then forms.settext(PowerUpsEnableButton,"PowerUps Off") end
end

function tipstoggle()
	TipsEnable = TipsEnable + 1
	if(TipsEnable > 1) then TipsEnable = 0 end
	if(TipsEnable == 1) then forms.settext(TipsEnableButton,"ShowTips On") end
	if(TipsEnable == 0) then forms.settext(TipsEnableButton,"ShowTips Off") end	
end

-- If PowerUps disabled remove these Relics.
function PowerUps_Proc()
	if(PowerUpsEnable > 0) then return end
	memory.write_u8(0x97969,0)
	memory.write_u8(0x9796A,0)
	memory.write_u8(0x9796C,0)
end

-- End of Power Ups Stuff

myForm = forms.newform(256+100+56,380,titlestr,closewindow)
myPB = forms.pictureBox(myForm,0,0,260-20+56,380)
NoItemCrashButton = forms.button(myForm,"ItemCrash On",subwptoggle,240+56,0,100,25)
MapTrackerEnableButton = forms.button(myForm,"Map Tracker On",maptrackertoggle,240+56,32,100,25)
PowerUpsEnableButton = forms.button(myForm,"Power Ups On",powerupstoggle,240+56,64,100,25)
TipsEnableButton = forms.button(myForm,"ShowTips On",tipstoggle,240+56,96,100,25)

function HideSetupButtons()
	forms.setproperty(NoItemCrashButton,"Enabled",0)
	forms.setproperty(PowerUpsEnableButton,"Enabled",0)
	--forms.setproperty(MapTrackerEnableButton,"Enabled",0)
end

function round(number)
  return number - (number % 1)
end


function autotimer()
	local zone = memory.read_u8(0x974A0,MainRAM)

		curHour = memory.read_u8(0x97C30,MainRAM)
		curMin = memory.read_u8(0x97C34,MainRAM)
		curSecs = memory.read_u8(0x97C38,MainRAM)

	if(zone == 0x1F and curHour == 0 and curMin == 0 and curSecs == 2) then
		console.log("Run Started!")
		RunStartFrame = emu.framecount()
		console.log("Frame:" .. RunStartFrame)
	end
	if(zone == 0x41 and curHour == 0 and curMin == 0 and curSecs == 0 and RunStartFrame == 0) then
		console.log("Run Started! " .. "Frame:" .. emu.framecount())
		RunStartFrame = emu.framecount()
		HideSetupButtons()
		--console.log("Frame:" .. RunStartFrame)
	end

	if(zone == 0x38 and RunEndFrame == 0) then
		if(memory.read_u8(0x76ED7) > 0x7F) then
			console.log("Run Ended! " .. "Frame:" .. emu.framecount())
			RunEndFrame = emu.framecount()
		end
	end
end

-- For Emu Frame Count Timer from Run Start
function buildautotimestr()
	if(RunStartFrame == 0) then
		timestr = "Run Timer - ??:??:??"
		return
	end
	
	if(RunEndFrame > 0) then
		curHour = (RunEndFrame - RunStartFrame) / 216000 % 99
		curMin = ((RunEndFrame - RunStartFrame) / 3600) % 60
		curSecs = ((RunEndFrame - RunStartFrame) / 60) % 60
	end

	if(RunEndFrame == 0) then
		curHour = (emu.framecount() - RunStartFrame) / 216000 % 99
		curMin = ((emu.framecount() - RunStartFrame) / 3600) % 60
		curSecs = ((emu.framecount() - RunStartFrame) / 60) % 60
	end

	curHour = math.floor(curHour)
	curMin = math.floor(curMin)
	curSecs = math.floor(curSecs)
	timestr = "Run Timer - "
	if curHour < 10 then
		timestr = timestr .. "0"
	end
	timestr = timestr .. curHour .. ":"
	if curMin < 10 then
		timestr = timestr .. "0"
	end
	timestr = timestr .. curMin .. ":"
	if curSecs < 10 then
		timestr = timestr .. "0"
	end
	timestr = timestr .. curSecs
end


-- For In Game Timer
function buildtimestr()
	if memory.read_u8(0x3C9A0,"MainRAM") > -1 then
		curHour = memory.read_u8(0x97C30,MainRAM)
		curMin = memory.read_u8(0x97C34,MainRAM)
		curSecs = memory.read_u8(0x97C38,MainRAM)
	end
	timestr = "Game Time - "
	if curHour < 10 then
		timestr = timestr .. "0"
	end
	timestr = timestr .. curHour .. ":"
	if curMin < 10 then
		timestr = timestr .. "0"
	end
	timestr = timestr .. curMin .. ":"
	if curSecs < 10 then
		timestr = timestr .. "0"
	end
	timestr = timestr .. curSecs
end

function movecursor()
	curX = curX + 60
	if curX >= (perRow * 60) then
		curX = 0
		curY = curY + 60
	end
end

function updatetracker()
	local fcards = 0
	curX = 0
	curY = 0
	forms.drawBox(myPB,0,0,240+56,340,0xFF110011, 0xFF110011)

	if memory.read_u8(0x9797D,"MainRAM") > 1 then
		forms.drawImage(myPB,"Images/HeartOfVlad.png",curX,curY,60,60,true)
		movecursor()
	end
	if memory.read_u8(0x9797E,"MainRAM") > 1 then
		forms.drawImage(myPB,"Images/ToothOfVlad.png",curX,curY,60,60,true)
		movecursor()
	end
	if memory.read_u8(0x9797F,"MainRAM") > 1 then
		forms.drawImage(myPB,"Images/RibOfVlad.png",curX,curY,60,60,true)
		movecursor()
	end
	if memory.read_u8(0x97980,"MainRAM") > 1 then
		forms.drawImage(myPB,"Images/RingOfVlad.png",curX,curY,60,60,true)
		movecursor()
	end
	if memory.read_u8(0x97981,"MainRAM") > 1 then
		forms.drawImage(myPB,"Images/EyeOfVlad.png",curX,curY,60,60,true)
		movecursor()
	end

	-- Forces Vlads on top row by themselves.
	curX = 0
	curY = 60

	if memory.read_u8(0x97A7B,"MainRAM") > 0 then
		forms.drawImage(myPB,"Images/GoldRing.png",curX,curY,60,60,true)
		movecursor()
	end
	if memory.read_u8(0x97A7C,"MainRAM") > 0 then
		forms.drawImage(myPB,"Images/SilverRing.png",curX,curY,60,60,true)
		movecursor()
	end
	if memory.read_u8(0x97A41,"MainRAM") > 0 or memory.read_u8(0x97C0C,"MainRAM") == 14 then
		forms.drawImage(myPB,"Images/Spikebreaker.png",curX,curY,60,60,true)
		movecursor()
	end
	if memory.read_u8(0x97A55,"MainRAM") > 0 then
		forms.drawImage(myPB,"Images/HolyGlasses.png",curX,curY,60,60,true)
		movecursor()
	end

	-- Forces Key Items on 2nd row by themselves.
	curX = 0
	curY = 120

	if memory.read_u8(0x97966,"MainRAM") > 1 then
		forms.drawImage(myPB,"Images/EchoOfBat.png",curX,curY,60,60,true)
		movecursor()
	end
	if memory.read_u8(0x97969,"MainRAM") > 1 then
		forms.drawImage(myPB,"Images/PowerOfWolf.png",curX,curY,60,60,true)
		movecursor()
	end
	if memory.read_u8(0x9796A,"MainRAM") > 1 then
		forms.drawImage(myPB,"Images/SkillOfWolf.png",curX,curY,60,60,true)
		movecursor()
	end
	if memory.read_u8(0x9796B,"MainRAM") > 1 then
		forms.drawImage(myPB,"Images/FormOfMist.png",curX,curY,60,60,true)
		movecursor()
	end
	if memory.read_u8(0x9796C,"MainRAM") > 1 then
		forms.drawImage(myPB,"Images/PowerOfMist.png",curX,curY,60,60,true)
		movecursor()
	end
--	if memory.read_u8(0x9796E,"MainRAM") > 1 then
--		forms.drawImage(myPB,"Images/CubeOfZoe.png",curX,curY,60,60,true)
--		movecursor()
--	end
--	if memory.read_u8(0x9796F,"MainRAM") > 1 then
--		forms.drawImage(myPB,"Images/SpiritOrb.png",curX,curY,60,60,true)
--		movecursor()
--	end
	if memory.read_u8(0x97974,"MainRAM") > 1 then
		forms.drawImage(myPB,"Images/JewelOfOpen.png",curX,curY,60,60,true)
		movecursor()
	end
	if memory.read_u8(0x97975,"MainRAM") > 1 then
		forms.drawImage(myPB,"Images/MermanStatue.png",curX,curY,60,60,true)
		movecursor()
	end
	if memory.read_u8(0x97973,"MainRAM") > 1 then
		forms.drawImage(myPB,"Images/FaerieScroll.png",curX,curY,60,60,true)
		movecursor()
	end
	if memory.read_u8(0x97A30,"MainRAM") > 0 then
		forms.drawImage(myPB,"Images/LibraryCard.png",curX,curY,60,60,true)
		forms.drawText(myPB,curX+4,curY+40,memory.read_u8(0x97A30,"MainRAM"),0xFFFFFFFF,0xFF000000, 16)
		movecursor()
	end

	-- Forces Health & Revive Items on 5th row by themselves.
	curX = 0
	curY = 240

	-- Faerie Card & Sprite Card. 
	if(memory.read_u8(0x97978,"MainRAM") > 0 ) then fcards = fcards + 1 end
	if(memory.read_u8(0x9797B,"MainRAM") > 0 ) then fcards = fcards + 1 end
	if fcards > 0 then
		forms.drawImage(myPB,"Images/FaerieCard.png",curX,curY,60,60,true)
		movecursor()
	end

	if memory.read_u8(0x97A1C,"MainRAM") > 0 then
		forms.drawImage(myPB,"Images/LifeApple.png",curX,curY,60,60,true)
		forms.drawText(myPB,curX+4,curY+40,memory.read_u8(0x97A1C,"MainRAM"),0xFFFFFFFF,0xFF000000, 16)
		movecursor()
	end

	if memory.read_u8(0x979A7,"MainRAM") > 0 then
		forms.drawImage(myPB,"Images/Food.png",curX,curY,60,60,true)
		forms.drawText(myPB,curX+4,curY+40,memory.read_u8(0x979A7,"MainRAM"),0xFFFFFFFF,0xFF000000, 16)
		movecursor()
	end


	--forms.drawText(myPB,0,200,"Time:" .. curHour .. curMin,0xFFFFFFFF,0xFF000000, 16)
	buildtimestr()
	if(RunEndFrame == 0 and RunStartFrame > 0) then
		forms.drawText(myPB,0,298,timestr,0xFFFFFFFF,0xFF000000, 16)
	end

	buildautotimestr()
	forms.drawText(myPB,0,320,timestr,0xFFFFFFFF,0xFF000000, 16)

	-- If NoItemCrash mode Enabled, Zone == 41, and Knife IC Cost == 0x0A
	-- Change all Item Crash Costs to 100 Hearts.
	if(NoItemCrash == 1 and memory.read_u8(0x974A0) == 0x41 and memory.read_u8(0x15482E) == 0x0A) then
		memory.write_u8(0x15482E,0x64,"MainRAM")
		memory.write_u8(0x15481A,0x64,"MainRAM")
		memory.write_u8(0x1547CA,0x64,"MainRAM")
		memory.write_u8(0x15477A,0x64,"MainRAM")
		memory.write_u8(0x154892,0x64,"MainRAM")
		memory.write_u8(0x1548A7,0x64,"MainRAM")
		memory.write_u8(0x15487E,0x64,"MainRAM")
		memory.write_u8(0x15486A,0x64,"MainRAM")
		memory.write_u8(0x1548BA,0x64,"MainRAM")
	end

	-- If NoItemCrash mode Disabled, Zone == 41, and Knife IC Cost == 0x64
	-- Change all Item Crash Costs back to original.
	if(NoItemCrash == 0 and memory.read_u8(0x974A0) == 0x41 and memory.read_u8(0x15482E) == 0x64) then
		memory.write_u8(0x15482E,0x0A,"MainRAM")
		memory.write_u8(0x15481A,0x0A,"MainRAM")
		memory.write_u8(0x1547CA,0x0F,"MainRAM")
		memory.write_u8(0x15477A,0x14,"MainRAM")
		memory.write_u8(0x154892,0x0F,"MainRAM")
		memory.write_u8(0x1548A7,0x14,"MainRAM")
		memory.write_u8(0x15487E,0x0A,"MainRAM")
		memory.write_u8(0x15486A,0x0A,"MainRAM")
		memory.write_u8(0x1548BA,0x14,"MainRAM")
	end

	forms.refresh(myPB)
end

function ByteToAscii(InputByte)
	if(InputByte == 0x20) then workstr = workstr .. " " end
	if(InputByte == 0x41) then workstr = workstr .. "A" end
	if(InputByte == 0x42) then workstr = workstr .. "B" end
	if(InputByte == 0x43) then workstr = workstr .. "C" end
	if(InputByte == 0x44) then workstr = workstr .. "D" end
	if(InputByte == 0x45) then workstr = workstr .. "E" end
	if(InputByte == 0x46) then workstr = workstr .. "F" end
	if(InputByte == 0x47) then workstr = workstr .. "G" end
	if(InputByte == 0x48) then workstr = workstr .. "H" end
	if(InputByte == 0x49) then workstr = workstr .. "I" end
	if(InputByte == 0x4A) then workstr = workstr .. "J" end
	if(InputByte == 0x4B) then workstr = workstr .. "K" end
	if(InputByte == 0x4C) then workstr = workstr .. "L" end
	if(InputByte == 0x4D) then workstr = workstr .. "M" end
	if(InputByte == 0x4E) then workstr = workstr .. "N" end
	if(InputByte == 0x4F) then workstr = workstr .. "O" end
	if(InputByte == 0x50) then workstr = workstr .. "P" end
	if(InputByte == 0x51) then workstr = workstr .. "Q" end
	if(InputByte == 0x52) then workstr = workstr .. "R" end
	if(InputByte == 0x53) then workstr = workstr .. "S" end
	if(InputByte == 0x54) then workstr = workstr .. "T" end
	if(InputByte == 0x55) then workstr = workstr .. "U" end
	if(InputByte == 0x56) then workstr = workstr .. "V" end
	if(InputByte == 0x57) then workstr = workstr .. "W" end
	if(InputByte == 0x58) then workstr = workstr .. "X" end
	if(InputByte == 0x59) then workstr = workstr .. "Y" end
	if(InputByte == 0x5A) then workstr = workstr .. "Z" end
end

function DecodeCard(cardindex)
	address = 0
	workstr = ""
	tempbyte = 0xff

	if(cardindex == 0 and memory.read_u8(0x9797A) == 0) then
		CardStr1 = "???"
		return
	end
	if(cardindex == 1 and memory.read_u8(0x97979) == 0) then
		CardStr2 = "???"
		return
	end
	if(cardindex == 2 and memory.read_u8(0x97978) == 0) then
		CardStr3 = "???"
		return
	end
	if(cardindex == 3 and memory.read_u8(0x97977) == 0) then
		CardStr4 = "???"
		return
	end
	if(cardindex == 4 and memory.read_u8(0x97976) == 0) then
		CardStr5 = "???"
		return
	end
	
	if(cardindex == 0) then address = 0xE0238 end
	if(cardindex == 1) then address = 0xE0264 end
	if(cardindex == 2) then address = 0xE0290 end
	if(cardindex == 3) then address = 0xE02C0 end
	if(cardindex == 4) then address = 0xE02EC end
	address = address + 7

	while tempbyte > 0 do
		tempbyte = memory.read_u8(address)
		if(tempbyte == 0) then break end
		ByteToAscii(tempbyte)
		address = address + 1
	end

	if(cardindex == 0) then CardStr1 = workstr end
	if(cardindex == 1) then CardStr2 = workstr end
	if(cardindex == 2) then CardStr3 = workstr end
	if(cardindex == 3) then CardStr4 = workstr end
	if(cardindex == 4) then CardStr5 = workstr end
end

function ReadCards()
	BHCheck = memory.read_u16_le(0xDB9B8)
	ShowCards = memory.read_u8(0x3C9A4)
	if(ShowCards == 0x70) then	-- Is Game Paused as Richter

		if(BHCheck == 0xFFD0) then
			gui.drawRectangle(30,14,200,60,0xFF0000FF,0xE0000000)
			gui.drawString(32,16,"Heart Card:" .. CardStr1)
			DecodeCard(0)
			gui.drawString(32,26,"Tooth Card:" .. CardStr2)
			DecodeCard(1)
			gui.drawString(32,36,"Rib Card  :" .. CardStr3)
			DecodeCard(2)
			gui.drawString(32,46,"Ring Card :" .. CardStr4)
			DecodeCard(3)
			gui.drawString(32,56,"Eye Card  :" .. CardStr5)
			DecodeCard(4)
			TipCounter = 0
		end
		if(TipsEnable == 1) then
			gui.drawRectangle(30,80,206,40,0xFF0000FF,0xE0000000)
			gui.drawString(32,82,"Use Food L2+R2+Up")
			gui.drawString(32,92,"Use Library Card L1+R1+O")
			gui.drawString(32,102,"Pocket Subweapon L2+R2+Down")
		end
	else
		if(TipCounter == 0) then 
			gui.clearGraphics()
		end
	end
end

function ExtraMistLocks()
	Zone = memory.read_u8(0x974A0)
	MistStatus = memory.read_u8(0x9796B)
	if(MistStatus == 0) then return end

	if(Zone == 0x01) then
		memory.write_u16_le(0x1983B4,0x01DA)
		memory.write_u16_le(0x198414,0x01DE)
		memory.write_u16_le(0x198474,0x01E9)
		memory.write_u16_le(0x1984D4,0x01E9)
	end
	if(Zone == 0x21) then
		memory.write_u16_le(0x18F0BA,0x01ED)
		memory.write_u16_le(0x18F11A,0x01E9)
		memory.write_u16_le(0x18F17A,0x01DE)
		memory.write_u16_le(0x18F1DA,0x01DA)
	end
	if(Zone == 0x2A) then
		memory.write_u16_le(0x194EB2,0x0266)
		memory.write_u16_le(0x194F52,0x031F)
		memory.write_u16_le(0x194FF2,0x0307)

	end
	if(Zone == 0x26) then
		memory.write_u16_le(0x18B26E,0x0000)
		memory.write_u16_le(0x18B30E,0x0000)
		memory.write_u16_le(0x18B3AE,0x0000)
		memory.write_u16_le(0x18B44E,0x0000)
	end
end

function ExtraLocks()
	BatStatus = memory.read_u8(0x97964)
	WolfStatus = memory.read_u8(0x97968)
	DemonStatus = memory.read_u8(0x97979)
	NDemonStatus = memory.read_u8(0x9797C)

	if(BatStatus == 3 and WolfStatus == 3) then
		memory.write_u8(0x3BE1F,0xF)
		memory.write_u8(0x3BE27,0xF)
	end

	if(DemonStatus == 3 and NDemonStatus == 3) then
		memory.write_u8(0x3BE3C,0x1)
		memory.write_u8(0x3BE44,0x1)
	end
end

function DrawTip(stringsel)
	TipCounter = 180
	gui.drawRectangle(47,179,191,20,0xFF0000FF,0xE0000000)
	if(stringsel == 0) then gui.drawString(50,182,"Extra BladeDash I-Frames") end
	if(stringsel == 1) then gui.drawString(50,182,"No Ground BladeDash Delay") end
	if(stringsel == 2) then gui.drawString(50,182,"Extra I-Frames on Damage") end
	if(stringsel == 3) then gui.drawString(50,182,"Library Teleport L1+R1+O") end
end

function PowerUpTips()
	if(TipsEnable == 1) then

		Cur_POW = memory.read_u8(0x97969)
		if(Pre_POW == 0 and Cur_POW == 3) then DrawTip(0) end
		Pre_POW = Cur_POW

		Cur_SOW = memory.read_u8(0x9796A)
		if(Pre_SOW == 0 and Cur_SOW == 3) then DrawTip(1) end
		Pre_SOW = Cur_SOW

		Cur_POM = memory.read_u8(0x9796C)
		if(Pre_POM == 0 and Cur_POM == 3) then DrawTip(2) end
		Pre_POM = Cur_POM

		Cur_FS = memory.read_u8(0x97973)
		if(Pre_FS == 0 and Cur_FS == 3) then DrawTip(3) end
		Pre_FS = Cur_FS

	end

	if(TipCounter > 0) then
		TipCounter = TipCounter - 1
		if(TipCounter == 0) then gui.clearGraphics() end
	end
end

-- Fix Annoying Warning Messages on Bizhawk 2.9 and above.
BizVersion = client.getversion()
if(bizstring.contains(BizVersion,"2.9")) then
	bit = (require "migration_helpers").EmuHawk_pre_2_9_bit();
end

while EndScript == false do -- The main cycle that causes the emulator to advance and trigger a game switch.
	updatefc = updatefc + 1
	if (updatefc >= 60) then
		updatetracker()
		updatefc = 0
		ExtraLocks()	-- Tracker Handles Unlocking some Extra stuff, until I hack it into the ROM
		ExtraMistLocks()
	end

	PowerUpTips()	-- Display Helpful Tips
	ReadCards()	-- Handle Bounty Hunter Mode reading Hint Cards
	autotimer()
	if(maptracker_en > 0) then UpdateMap() end
	if(PowerUpsEnable < 1) then PowerUps_Proc() end
	emu.frameadvance()
	
end

