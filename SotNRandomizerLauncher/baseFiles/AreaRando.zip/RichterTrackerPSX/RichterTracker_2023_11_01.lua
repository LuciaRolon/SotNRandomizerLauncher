--[[
	Castlevania SotN - Richter Randomizer Item Tracker
	By MottZilla
	Version: 2023, November 1st
	Many Images taken from https://github.com/TalicZealot/SotN-Relic-Tracker
]]--

titlestr = "Richter Tracker - May 23rd 2023"
EndScript = false	-- Terminate Script Flag
NoItemCrash = 0		-- No Item Crashes Mode
PowerUpsEnable = 1	-- Richter Ability PowerUps Enable
updatefc = 0
curX = 0
curY = 0
perRow = 5
curHour = 0
curMin = 0
curSecs = 0
timestr = "Time - 00:00"
RunStartFrame = 0
RunEndFrame = 0
NoItemCrash = 0
MapUpdateZone = 64

-- Castle Check Coords
c1r_x = {  13, 77,101, 61, 53, 33, 85, 33, 65, 81,125,125,157,237,245,237,209,197,193,137,129,181,161,221,117, 69,165}
c1r_y = { 133,125,109,113, 89, 41, 69,149, 45, 53, 25, 17,  9, 25, 53, 53, 53, 61, 65, 73,105,113,133,145,157,181,185}
c2r_x = { 161, 97,233, 81, 81, 53,161,221,121, 69}
c2r_y = {  21, 33, 73, 45, 69, 89,133,145,141,181}
maptracker_en = 1

-- Map Tracker Code Begins here
function DrawPix(xloc,yloc)
local vptr
local pixel
	vptr = 0x8A680
	vptr = vptr + (xloc/2) + (yloc * 0x800)
	pixel = memory.read_u8(vptr,"GPURAM")
	if(bit.band(xloc,1) == 1) then
		pixel = bit.band(pixel,0x0F)
		pixel = bit.bor(pixel,0x70)
	end
	if(bit.band(xloc,1) == 0) then
		pixel = bit.band(pixel,0xF0)
		pixel = bit.bor(pixel,0x07)
	end

	--console.log(bizstring.hex(vptr))
	memory.write_u8(vptr,pixel,"GPURAM")
end

function DrawBox(xloc,yloc)
local x,y
	for x = 0,2,1 do
		for y = 0,2,1 do
			DrawPix(xloc+x,yloc+y)
		end
	end
end

function UpdateMap()
	if(maptracker_en == 0) then return end
	zone = memory.read_u8(0x974A0)

	if(zone == 0x45) then
		MapUpdateZone = 64
		return
	end
	
	if(memory.read_u8(0x3C9A4) == 0x14) then

	if(MapUpdateZone == zone) then return end
	MapUpdateZone = zone
	for n = 1, 30,1
	do
		if( bit.band(zone,0x20) == 0) then		-- If Castle 1
			if(c1r_x[n] == nil) then break end
			DrawBox(c1r_x[n],c1r_y[n])
		end

		if( bit.band(zone,0x20) == 0x20) then		-- If Castle 2
			if(c2r_x[n] == nil) then break end
			DrawBox(c2r_x[n],c2r_y[n])
		end
	end
		
	end	-- EndIf 3C9A4 == 0x14
end
-- Map Tracker Stuff ^^


function closewindow()
	forms.destroyall()
	console.log("Window Closed!")
	EndScript = true
end

function subwptoggle()
	if(RunStartFrame>0) then return end	-- Can't Toggle after Run Begins
	NoItemCrash = NoItemCrash + 1
	if(NoItemCrash > 1) then NoItemCrash = 0 end
	if(NoItemCrash == 0) then forms.settext(NoItemCrashButton,"ItemCrash On") end
	if(NoItemCrash == 1) then forms.settext(NoItemCrashButton,"ItemCrash Off") end
end

function maptrackertoggle()
	--if(RunStartFrame>0) then return end	-- Can't Toggle after Run Begins
	maptracker_en = maptracker_en + 1
	if(maptracker_en > 1) then maptracker_en = 0 end
	if(maptracker_en == 1) then forms.settext(MapTrackerEnableButton,"Map Tracker On") end
	if(maptracker_en == 0) then forms.settext(MapTrackerEnableButton,"Map Tracker Off") end
end

function powerupstoggle()
	if(RunStartFrame>0) then return end	-- Can't Toggle after Run Begins
	PowerUpsEnable = PowerUpsEnable + 1
	if(PowerUpsEnable > 1) then PowerUpsEnable = 0 end
	if(PowerUpsEnable == 1) then forms.settext(PowerUpsEnableButton,"PowerUps On") end
	if(PowerUpsEnable == 0) then forms.settext(PowerUpsEnableButton,"PowerUps Off") end
end

-- If PowerUps disabled remove these Relics.
function PowerUps_Proc()
	if(PowerUpsEnable > 0) then return end
	memory.write_u8(0x97969,0)
	memory.write_u8(0x9796A,0)
	memory.write_u8(0x9796C,0)
end

-- End of Power Ups Stuff

myForm = forms.newform(256+100+56,380,titlestr,closewindow)
myPB = forms.pictureBox(myForm,0,0,260-20+56,380)
NoItemCrashButton = forms.button(myForm,"ItemCrash On",subwptoggle,240+56,0,100,25)
MapTrackerEnableButton = forms.button(myForm,"Map Tracker On",maptrackertoggle,240+56,32,100,25)
PowerUpsEnableButton = forms.button(myForm,"Power Ups On",powerupstoggle,240+56,64,100,25)

function HideSetupButtons()
	forms.setproperty(NoItemCrashButton,"Enabled",0)
	forms.setproperty(PowerUpsEnableButton,"Enabled",0)
	--forms.setproperty(MapTrackerEnableButton,"Enabled",0)
end

function round(number)
  return number - (number % 1)
end


function autotimer()
	local zone = memory.read_u8(0x974A0,MainRAM)

		curHour = memory.read_u8(0x97C30,MainRAM)
		curMin = memory.read_u8(0x97C34,MainRAM)
		curSecs = memory.read_u8(0x97C38,MainRAM)

	if(zone == 0x1F and curHour == 0 and curMin == 0 and curSecs == 2) then
		console.log("Run Started!")
		RunStartFrame = emu.framecount()
		console.log("Frame:" .. RunStartFrame)
	end
	if(zone == 0x41 and curHour == 0 and curMin == 0 and curSecs == 0 and RunStartFrame == 0) then
		console.log("Run Started! " .. "Frame:" .. emu.framecount())
		RunStartFrame = emu.framecount()
		HideSetupButtons()
		--console.log("Frame:" .. RunStartFrame)
	end

	if(zone == 0x38 and RunEndFrame == 0) then
		if(memory.read_u8(0x76ED7) > 0x7F) then
			console.log("Run Ended! " .. "Frame:" .. emu.framecount())
			RunEndFrame = emu.framecount()
		end
	end
end

-- For Emu Frame Count Timer from Run Start
function buildautotimestr()
	if(RunStartFrame == 0) then
		timestr = "Run Timer - ??:??:??"
		return
	end
	
	if(RunEndFrame > 0) then
		curHour = (RunEndFrame - RunStartFrame) / 216000 % 99
		curMin = ((RunEndFrame - RunStartFrame) / 3600) % 60
		curSecs = ((RunEndFrame - RunStartFrame) / 60) % 60
	end

	if(RunEndFrame == 0) then
		curHour = (emu.framecount() - RunStartFrame) / 216000 % 99
		curMin = ((emu.framecount() - RunStartFrame) / 3600) % 60
		curSecs = ((emu.framecount() - RunStartFrame) / 60) % 60
	end

	--[[
	curHour = round(curHour)
	curMin = round(curMin)
	curSecs = round(curSecs)
	]]--
	curHour = math.floor(curHour)
	curMin = math.floor(curMin)
	curSecs = math.floor(curSecs)

	timestr = "Run Timer - "
	if curHour < 10 then
		timestr = timestr .. "0"
	end
	timestr = timestr .. curHour .. ":"
	if curMin < 10 then
		timestr = timestr .. "0"
	end
	timestr = timestr .. curMin .. ":"
	if curSecs < 10 then
		timestr = timestr .. "0"
	end
	timestr = timestr .. curSecs
end


-- For In Game Timer
function buildtimestr()
	if memory.read_u8(0x3C9A0,"MainRAM") > -1 then
		curHour = memory.read_u8(0x97C30,MainRAM)
		curMin = memory.read_u8(0x97C34,MainRAM)
		curSecs = memory.read_u8(0x97C38,MainRAM)
	end
	timestr = "Game Time - "
	if curHour < 10 then
		timestr = timestr .. "0"
	end
	timestr = timestr .. curHour .. ":"
	if curMin < 10 then
		timestr = timestr .. "0"
	end
	timestr = timestr .. curMin .. ":"
	if curSecs < 10 then
		timestr = timestr .. "0"
	end
	timestr = timestr .. curSecs
end

function movecursor()
	curX = curX + 60
	if curX >= (perRow * 60) then
		curX = 0
		curY = curY + 60
	end
end

function updatetracker()
	local fcards = 0
	curX = 0
	curY = 0
	forms.drawBox(myPB,0,0,240+56,340,0xFF110011, 0xFF110011)

	if memory.read_u8(0x9797D,"MainRAM") > 1 then
		forms.drawImage(myPB,"Images/HeartOfVlad.png",curX,curY,60,60,true)
		movecursor()
	end
	if memory.read_u8(0x9797E,"MainRAM") > 1 then
		forms.drawImage(myPB,"Images/ToothOfVlad.png",curX,curY,60,60,true)
		movecursor()
	end
	if memory.read_u8(0x9797F,"MainRAM") > 1 then
		forms.drawImage(myPB,"Images/RibOfVlad.png",curX,curY,60,60,true)
		movecursor()
	end
	if memory.read_u8(0x97980,"MainRAM") > 1 then
		forms.drawImage(myPB,"Images/RingOfVlad.png",curX,curY,60,60,true)
		movecursor()
	end
	if memory.read_u8(0x97981,"MainRAM") > 1 then
		forms.drawImage(myPB,"Images/EyeOfVlad.png",curX,curY,60,60,true)
		movecursor()
	end

	-- Forces Vlads on top row by themselves.
	curX = 0
	curY = 60

	if memory.read_u8(0x97A7B,"MainRAM") > 0 then
		forms.drawImage(myPB,"Images/GoldRing.png",curX,curY,60,60,true)
		movecursor()
	end
	if memory.read_u8(0x97A7C,"MainRAM") > 0 then
		forms.drawImage(myPB,"Images/SilverRing.png",curX,curY,60,60,true)
		movecursor()
	end
	if memory.read_u8(0x97A41,"MainRAM") > 0 or memory.read_u8(0x97C0C,"MainRAM") == 14 then
		forms.drawImage(myPB,"Images/Spikebreaker.png",curX,curY,60,60,true)
		movecursor()
	end
	if memory.read_u8(0x97A55,"MainRAM") > 0 then
		forms.drawImage(myPB,"Images/HolyGlasses.png",curX,curY,60,60,true)
		movecursor()
	end

	-- Forces Key Items on 2nd row by themselves.
	curX = 0
	curY = 120

	if memory.read_u8(0x97966,"MainRAM") > 1 then
		forms.drawImage(myPB,"Images/EchoOfBat.png",curX,curY,60,60,true)
		movecursor()
	end
	if memory.read_u8(0x97969,"MainRAM") > 1 then
		forms.drawImage(myPB,"Images/PowerOfWolf.png",curX,curY,60,60,true)
		movecursor()
	end
	if memory.read_u8(0x9796A,"MainRAM") > 1 then
		forms.drawImage(myPB,"Images/SkillOfWolf.png",curX,curY,60,60,true)
		movecursor()
	end
	if memory.read_u8(0x9796B,"MainRAM") > 1 then
		forms.drawImage(myPB,"Images/FormOfMist.png",curX,curY,60,60,true)
		movecursor()
	end
	if memory.read_u8(0x9796C,"MainRAM") > 1 then
		forms.drawImage(myPB,"Images/PowerOfMist.png",curX,curY,60,60,true)
		movecursor()
	end
--	if memory.read_u8(0x9796E,"MainRAM") > 1 then
--		forms.drawImage(myPB,"Images/CubeOfZoe.png",curX,curY,60,60,true)
--		movecursor()
--	end
--	if memory.read_u8(0x9796F,"MainRAM") > 1 then
--		forms.drawImage(myPB,"Images/SpiritOrb.png",curX,curY,60,60,true)
--		movecursor()
--	end
	if memory.read_u8(0x97974,"MainRAM") > 1 then
		forms.drawImage(myPB,"Images/JewelOfOpen.png",curX,curY,60,60,true)
		movecursor()
	end
	if memory.read_u8(0x97975,"MainRAM") > 1 then
		forms.drawImage(myPB,"Images/MermanStatue.png",curX,curY,60,60,true)
		movecursor()
	end
	if memory.read_u8(0x97973,"MainRAM") > 1 then
		forms.drawImage(myPB,"Images/FaerieScroll.png",curX,curY,60,60,true)
		movecursor()
	end
	if memory.read_u8(0x97A30,"MainRAM") > 0 then
		forms.drawImage(myPB,"Images/LibraryCard.png",curX,curY,60,60,true)
		forms.drawText(myPB,curX+4,curY+40,memory.read_u8(0x97A30,"MainRAM"),0xFFFFFFFF,0xFF000000, 16)
		movecursor()
	end

	-- Forces Health & Revive Items on 5th row by themselves.
	curX = 0
	curY = 240

	-- Faerie Card & Sprite Card. 
	if(memory.read_u8(0x97978,"MainRAM") > 0 ) then fcards = fcards + 1 end
	if(memory.read_u8(0x9797B,"MainRAM") > 0 ) then fcards = fcards + 1 end
	if fcards > 0 then
		forms.drawImage(myPB,"Images/FaerieCard.png",curX,curY,60,60,true)
		movecursor()
	end

	if memory.read_u8(0x97A1C,"MainRAM") > 0 then
		forms.drawImage(myPB,"Images/LifeApple.png",curX,curY,60,60,true)
		forms.drawText(myPB,curX+4,curY+40,memory.read_u8(0x97A1C,"MainRAM"),0xFFFFFFFF,0xFF000000, 16)
		movecursor()
	end

	if memory.read_u8(0x979A7,"MainRAM") > 0 then
		forms.drawImage(myPB,"Images/Food.png",curX,curY,60,60,true)
		forms.drawText(myPB,curX+4,curY+40,memory.read_u8(0x979A7,"MainRAM"),0xFFFFFFFF,0xFF000000, 16)
		movecursor()
	end


	--forms.drawText(myPB,0,200,"Time:" .. curHour .. curMin,0xFFFFFFFF,0xFF000000, 16)
	buildtimestr()
	if(RunEndFrame == 0 and RunStartFrame > 0) then
		forms.drawText(myPB,0,298,timestr,0xFFFFFFFF,0xFF000000, 16)
	end

	buildautotimestr()
	forms.drawText(myPB,0,320,timestr,0xFFFFFFFF,0xFF000000, 16)

	-- If NoItemCrash mode Enabled, Zone == 41, and Knife IC Cost == 0x0A
	-- Change all Item Crash Costs to 100 Hearts.
	if(NoItemCrash == 1 and memory.read_u8(0x974A0) == 0x41 and memory.read_u8(0x15482E) == 0x0A) then
		memory.write_u8(0x15482E,0x64,"MainRAM")
		memory.write_u8(0x15481A,0x64,"MainRAM")
		memory.write_u8(0x1547CA,0x64,"MainRAM")
		memory.write_u8(0x15477A,0x64,"MainRAM")
		memory.write_u8(0x154892,0x64,"MainRAM")
		memory.write_u8(0x1548A7,0x64,"MainRAM")
		memory.write_u8(0x15487E,0x64,"MainRAM")
		memory.write_u8(0x15486A,0x64,"MainRAM")
		memory.write_u8(0x1548BA,0x64,"MainRAM")
	end

	-- If NoItemCrash mode Disabled, Zone == 41, and Knife IC Cost == 0x64
	-- Change all Item Crash Costs back to original.
	if(NoItemCrash == 0 and memory.read_u8(0x974A0) == 0x41 and memory.read_u8(0x15482E) == 0x64) then
		memory.write_u8(0x15482E,0x0A,"MainRAM")
		memory.write_u8(0x15481A,0x0A,"MainRAM")
		memory.write_u8(0x1547CA,0x0F,"MainRAM")
		memory.write_u8(0x15477A,0x14,"MainRAM")
		memory.write_u8(0x154892,0x0F,"MainRAM")
		memory.write_u8(0x1548A7,0x14,"MainRAM")
		memory.write_u8(0x15487E,0x0A,"MainRAM")
		memory.write_u8(0x15486A,0x0A,"MainRAM")
		memory.write_u8(0x1548BA,0x14,"MainRAM")
	end

	forms.refresh(myPB)
end

BizVersion = client.getversion()
if(bizstring.contains(BizVersion,"2.9")) then
	bit = (require "migration_helpers").EmuHawk_pre_2_9_bit();
end

while EndScript == false do -- The main cycle that causes the emulator to advance and trigger a game switch.
	updatefc = updatefc + 1
	if (updatefc >= 60) then
		updatetracker()
		updatefc = 0
	end

	autotimer()
	if(maptracker_en > 0) then UpdateMap() end
	if(PowerUpsEnable < 1) then PowerUps_Proc() end
	emu.frameadvance()
	
end

